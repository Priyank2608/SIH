from typing import Dict, Any
from sqlalchemy.orm import Session
from app.models.entities import BidderDocument, OCRResult, VerificationResult, EvidenceRecord
from app.adapters.verification.base import provider_registry
from app.services.audit_service import log_audit_event

def run_verification_for_document(
    db: Session,
    document_id: int,
    user_id: int = 1,
    username: str = "officer"
) -> VerificationResult:
    doc = db.query(BidderDocument).filter(BidderDocument.id == document_id).first()
    if not doc:
        raise ValueError(f"Document with ID {document_id} not found")

    ocr = db.query(OCRResult).filter(OCRResult.document_id == doc.id).first()
    bidder = doc.bidder
    adapter = provider_registry.get_adapter(doc.document_type)

    verif_data = adapter.verify(doc, ocr, bidder)

    # Check for existing result
    existing = db.query(VerificationResult).filter(VerificationResult.document_id == doc.id).first()
    if existing:
        existing.provider_name = adapter.provider_name
        existing.status = verif_data["status"]
        existing.raw_response = verif_data.get("raw_response", {})
        existing.discrepancy_notes = verif_data.get("discrepancy_notes")
        existing.retry_count = existing.retry_count + 1
        res = existing
    else:
        res = VerificationResult(
            document_id=doc.id,
            provider_name=adapter.provider_name,
            status=verif_data["status"],
            raw_response=verif_data.get("raw_response", {}),
            discrepancy_notes=verif_data.get("discrepancy_notes"),
            retry_count=0
        )
        db.add(res)

    db.commit()
    db.refresh(res)

    # Create / update Evidence Record
    evidence_text = f"Verification outcome: {res.status} via {res.provider_name}."
    if res.discrepancy_notes:
        evidence_text += f" Notes: {res.discrepancy_notes}"
    else:
        evidence_text += f" Confirmed genuine record against verified demo registry."

    ev = EvidenceRecord(
        tender_id=doc.tender_id,
        bidder_id=bidder.id,
        document_id=doc.id,
        ocr_result_id=ocr.id if ocr else None,
        verification_result_id=res.id,
        claim_type=f"{doc.document_type}_VERIFICATION",
        evidence_text=evidence_text,
        source_reference=f"Doc#{doc.id} ({doc.document_type} v{doc.version})",
        confidence=0.98 if res.status == "VERIFIED" else 0.85
    )
    db.add(ev)
    db.commit()

    log_audit_event(
        db,
        action="VERIFICATION_COMPLETED",
        entity_type="DOCUMENT",
        entity_id=str(doc.id),
        user_id=user_id,
        username=username,
        details={
            "document_type": doc.document_type,
            "provider": res.provider_name,
            "status": res.status,
            "has_discrepancy": bool(res.discrepancy_notes)
        }
    )

    return res
