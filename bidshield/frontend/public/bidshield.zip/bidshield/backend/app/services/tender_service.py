from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from app.models.entities import Tender, TenderRequirement, TenderBidder, Bidder
from app.services.audit_service import log_audit_event

def extract_requirements_from_text(text: str) -> List[Dict[str, Any]]:
    """Heuristic rule-based and AI pattern extraction of procurement requirements from tender documents."""
    reqs = []
    
    # GST requirement
    if "GST" in text.upper():
        reqs.append({
            "code": "GST-001",
            "name": "Goods and Services Tax (GST) Registration",
            "requirement_type": "MANDATORY",
            "description": "Bidder must possess a valid, operative GSTIN registered in India.",
            "structured_rule": {"doc_type": "GST", "required_status": "ACTIVE"},
            "source_page": 1,
            "confidence": 0.98
        })

    # PAN requirement
    if "PAN" in text.upper():
        reqs.append({
            "code": "PAN-001",
            "name": "Permanent Account Number (PAN)",
            "requirement_type": "MANDATORY",
            "description": "Bidder must furnish a valid PAN card issued by the Income Tax Department.",
            "structured_rule": {"doc_type": "PAN", "check_format": True},
            "source_page": 1,
            "confidence": 0.99
        })

    # Udyam / MSME requirement
    if any(k in text.upper() for k in ["UDYAM", "MSME"]):
        reqs.append({
            "code": "UDYAM-001",
            "name": "MSME / Udyam Registration Certificate",
            "requirement_type": "OPTIONAL",
            "description": "Valid Udyam Registration certificate for availing purchase preference/EMD exemption.",
            "structured_rule": {"doc_type": "UDYAM", "valid_date_check": True},
            "source_page": 2,
            "confidence": 0.95
        })

    # OEM Authorization
    if "OEM" in text.upper() or "MANUFACTURER" in text.upper():
        reqs.append({
            "code": "OEM-001",
            "name": "Original Equipment Manufacturer (OEM) Authorization",
            "requirement_type": "MANDATORY",
            "description": "Direct Manufacturer Authorization Form (MAF) certifying bidder as authorized reseller.",
            "structured_rule": {"doc_type": "OEM", "partner_status": "CERTIFIED"},
            "source_page": 2,
            "confidence": 0.94
        })

    # Past Experience
    if any(k in text.upper() for k in ["EXPERIENCE", "CONTRACT VALUE", "PAST PERFORMANCE"]):
        reqs.append({
            "code": "EXP-001",
            "name": "Past Experience Criteria",
            "requirement_type": "TECHNICAL",
            "description": "At least 3 years satisfactory past contract execution with similar procurement scope.",
            "structured_rule": {"doc_type": "EXPERIENCE", "min_years": 3},
            "source_page": 3,
            "confidence": 0.92
        })

    # Financial Turnover
    if any(k in text.upper() for k in ["TURNOVER", "ANNUAL TURNOVER", "CA CERTIFICATE"]):
        reqs.append({
            "code": "TURNOVER-001",
            "name": "Annual Financial Turnover (Audited)",
            "requirement_type": "FINANCIAL",
            "description": "Average audited annual turnover over past 3 financial years certified by Chartered Accountant.",
            "structured_rule": {"doc_type": "TURNOVER", "min_turnover_cr": 2.0},
            "source_page": 3,
            "confidence": 0.93
        })

    # Local Content / Make in India
    if any(k in text.upper() for k in ["LOCAL CONTENT", "MAKE IN INDIA", "MII"]):
        reqs.append({
            "code": "LOCAL-001",
            "name": "Make in India (Class-I / Class-II Local Content)",
            "requirement_type": "MANDATORY",
            "description": "Self-declaration of local value addition exceeding statutory threshold (>= 50%).",
            "structured_rule": {"doc_type": "LOCAL_CONTENT", "min_pct": 50},
            "source_page": 4,
            "confidence": 0.96
        })

    return reqs

def process_tender_requirements(
    db: Session,
    tender_id: int,
    user_id: int = 1,
    username: str = "officer"
) -> List[TenderRequirement]:
    tender = db.query(Tender).filter(Tender.id == tender_id).first()
    if not tender:
        raise ValueError(f"Tender {tender_id} not found")

    text_corpus = f"{tender.title} {tender.department} {tender.category} {tender.description or ''}"
    extracted = extract_requirements_from_text(text_corpus)

    created = []
    for item in extracted:
        # Check if already exists
        exists = db.query(TenderRequirement).filter(
            TenderRequirement.tender_id == tender_id,
            TenderRequirement.code == item["code"]
        ).first()
        if not exists:
            req = TenderRequirement(
                tender_id=tender_id,
                code=item["code"],
                name=item["name"],
                requirement_type=item["requirement_type"],
                description=item["description"],
                structured_rule=item["structured_rule"],
                source_page=item["source_page"],
                confidence=item["confidence"],
                approval_status="PENDING",
                officer_notes="AI extracted. Awaiting procurement officer review and formal approval."
            )
            db.add(req)
            created.append(req)

    db.commit()

    log_audit_event(
        db,
        action="REQUIREMENTS_EXTRACTED",
        entity_type="TENDER",
        entity_id=str(tender.id),
        user_id=user_id,
        username=username,
        details={"extracted_count": len(created)}
    )

    return db.query(TenderRequirement).filter(TenderRequirement.tender_id == tender_id).all()
