from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from app.models.entities import AuditLog

def log_audit_event(
    db: Session,
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    user_id: Optional[int] = None,
    username: str = "system",
    tenant_id: int = 1,
    ip_address: str = "127.0.0.1",
    details: Optional[Dict[str, Any]] = None
) -> AuditLog:
    entry = AuditLog(
        tenant_id=tenant_id,
        user_id=user_id,
        username=username,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        ip_address=ip_address,
        details=details or {}
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry
