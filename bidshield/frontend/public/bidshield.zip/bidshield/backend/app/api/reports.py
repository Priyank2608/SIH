from typing import List
from fastapi import APIRouter, Depends, HTTPException, Response, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import GeneratedReport
from app.schemas.schemas import GeneratedReportOut
from app.core.security import get_current_user, AuthenticatedUser
from app.services.report_service import generate_quick_bidder_list_pdf, generate_detailed_bidder_assessment_pdf
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/reports", tags=["Reports"])

class QuickListRequest(BaseModel):
    tender_id: int

class DetailedAssessmentRequest(BaseModel):
    tender_id: int
    bidder_id: int

@router.get("", response_model=List[GeneratedReportOut])
def list_reports(db: Session = Depends(get_db)):
    return db.query(GeneratedReport).order_by(GeneratedReport.id.desc()).all()

@router.post("/quick-list", response_model=GeneratedReportOut)
def create_quick_list_report(
    payload: QuickListRequest,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    try:
        rep = generate_quick_bidder_list_pdf(db, payload.tender_id, user.id, user.username)
        return rep
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate quick summary report: {str(e)}")

@router.post("/detailed-assessment", response_model=GeneratedReportOut)
def create_detailed_assessment_report(
    payload: DetailedAssessmentRequest,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    try:
        rep = generate_detailed_bidder_assessment_pdf(db, payload.tender_id, payload.bidder_id, user.id, user.username)
        return rep
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate detailed assessment dossier: {str(e)}")

@router.get("/{report_uid}/download")
def download_report(
    report_uid: str,
    db: Session = Depends(get_db)
):
    rep = db.query(GeneratedReport).filter(GeneratedReport.report_uid == report_uid).first()
    if not rep or not rep.file_bytes:
        raise HTTPException(status_code=404, detail="Report not found")

    rep.download_count += 1
    db.commit()

    log_audit_event(
        db,
        action="REPORT_DOWNLOADED",
        entity_type="REPORT",
        entity_id=rep.report_uid,
        details={"filename": rep.filename, "download_count": rep.download_count}
    )

    return Response(
        content=rep.file_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={rep.filename}",
            "X-Report-SHA256": rep.file_hash
        }
    )
