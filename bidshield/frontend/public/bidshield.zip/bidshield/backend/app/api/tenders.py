from datetime import datetime, timezone
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import Tender, TenderRequirement, TenderBidder, Bidder, ComplianceResult, EvidenceRecord
from app.schemas.schemas import (
    TenderOut, TenderDetailOut, TenderCreate, TenderRequirementOut,
    RequirementCreate, RequirementUpdate, OfficerDecisionRequest
)
from app.core.security import get_current_user, AuthenticatedUser
from app.services.tender_service import process_tender_requirements
from app.services.ocr_service import run_ocr_for_document
from app.services.verification_service import run_verification_for_document
from app.services.compliance_service import evaluate_compliance
from app.services.risk_service import calculate_bidder_risk
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/tenders", tags=["Tenders"])

@router.get("", response_model=List[TenderOut])
def list_tenders(db: Session = Depends(get_db)):
    tenders = db.query(Tender).order_by(Tender.id.asc()).all()
    out = []
    for t in tenders:
        reqs = db.query(TenderRequirement).filter(TenderRequirement.tender_id == t.id).all()
        bidder_count = db.query(TenderBidder).filter(TenderBidder.tender_id == t.id).count()
        out.append({
            "id": t.id,
            "tender_ref": t.tender_ref,
            "gem_ref": t.gem_ref,
            "title": t.title,
            "department": t.department,
            "category": t.category,
            "description": t.description,
            "estimated_value_cr": t.estimated_value_cr,
            "issue_date": t.issue_date,
            "closing_date": t.closing_date,
            "status": t.status,
            "pdf_filename": t.pdf_filename,
            "created_at": t.created_at,
            "requirements": reqs,
            "bidders_count": bidder_count
        })
    return out

@router.post("", response_model=TenderOut)
def create_tender(
    payload: TenderCreate,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    existing = db.query(Tender).filter(Tender.tender_ref == payload.tender_ref).first()
    if existing:
        raise HTTPException(status_code=400, detail="Tender reference already exists")

    t = Tender(
        tenant_id=user.tenant_id,
        tender_ref=payload.tender_ref,
        gem_ref=payload.gem_ref,
        title=payload.title,
        department=payload.department,
        category=payload.category,
        description=payload.description,
        estimated_value_cr=payload.estimated_value_cr,
        issue_date=payload.issue_date,
        closing_date=payload.closing_date,
        status="ACTIVE",
        created_by_id=user.id
    )
    db.add(t)
    db.commit()
    db.refresh(t)

    # Automatically extract initial requirements
    process_tender_requirements(db, t.id, user.id, user.username)

    log_audit_event(
        db,
        action="TENDER_CREATED",
        entity_type="TENDER",
        entity_id=str(t.id),
        user_id=user.id,
        username=user.username,
        details={"tender_ref": t.tender_ref, "title": t.title}
    )

    reqs = db.query(TenderRequirement).filter(TenderRequirement.tender_id == t.id).all()
    return {
        "id": t.id,
        "tender_ref": t.tender_ref,
        "gem_ref": t.gem_ref,
        "title": t.title,
        "department": t.department,
        "category": t.category,
        "description": t.description,
        "estimated_value_cr": t.estimated_value_cr,
        "issue_date": t.issue_date,
        "closing_date": t.closing_date,
        "status": t.status,
        "pdf_filename": t.pdf_filename,
        "created_at": t.created_at,
        "requirements": reqs,
        "bidders_count": 0
    }

@router.get("/{id}", response_model=TenderDetailOut)
def get_tender(id: int, db: Session = Depends(get_db)):
    t = db.query(Tender).filter(Tender.id == id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Tender not found")

    reqs = db.query(TenderRequirement).filter(TenderRequirement.tender_id == t.id).order_by(TenderRequirement.id.asc()).all()
    tbs = db.query(TenderBidder).filter(TenderBidder.tender_id == t.id).all()

    bidders_list = []
    for tb in tbs:
        b = tb.bidder
        bidders_list.append({
            "id": b.id,
            "legal_name": b.legal_name,
            "trade_name": b.trade_name,
            "pan": b.pan,
            "gstin": b.gstin,
            "enterprise_type": b.enterprise_type,
            "is_startup": b.is_startup,
            "state": b.state,
            "compliance_status": tb.compliance_status,
            "compliance_score": tb.compliance_score,
            "risk_level": tb.risk_level,
            "final_decision": tb.final_decision,
            "decision_notes": tb.decision_notes
        })

    return {
        "id": t.id,
        "tender_ref": t.tender_ref,
        "gem_ref": t.gem_ref,
        "title": t.title,
        "department": t.department,
        "category": t.category,
        "description": t.description,
        "estimated_value_cr": t.estimated_value_cr,
        "issue_date": t.issue_date,
        "closing_date": t.closing_date,
        "status": t.status,
        "pdf_filename": t.pdf_filename,
        "created_at": t.created_at,
        "requirements": reqs,
        "bidders_count": len(bidders_list),
        "bidders": bidders_list
    }

@router.post("/{id}/extract-requirements")
def trigger_requirement_extraction(
    id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    reqs = process_tender_requirements(db, id, user.id, user.username)
    return {"message": "Requirements extracted successfully", "requirements": reqs}

@router.post("/{id}/requirements", response_model=TenderRequirementOut)
def add_requirement(
    id: int,
    payload: RequirementCreate,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    existing = db.query(TenderRequirement).filter(
        TenderRequirement.tender_id == id,
        TenderRequirement.code == payload.code
    ).first()
    if existing:
        return existing

    req = TenderRequirement(
        tender_id=id,
        code=payload.code,
        name=payload.name,
        requirement_type=payload.requirement_type,
        description=payload.description,
        structured_rule=payload.structured_rule,
        approval_status="APPROVED",
        approving_officer_id=user.id,
        approved_at=datetime.now(timezone.utc),
        officer_notes="Manually created and approved by Procurement Officer."
    )
    db.add(req)
    db.commit()
    db.refresh(req)

    log_audit_event(
        db,
        action="REQUIREMENT_CREATED",
        entity_type="TENDER_REQUIREMENT",
        entity_id=str(req.id),
        user_id=user.id,
        username=user.username,
        details={"code": req.code, "name": req.name}
    )
    return req

@router.put("/{id}/requirements/{req_id}", response_model=TenderRequirementOut)
def update_requirement(
    id: int,
    req_id: int,
    payload: RequirementUpdate,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    req = db.query(TenderRequirement).filter(
        TenderRequirement.id == req_id,
        TenderRequirement.tender_id == id
    ).first()
    if not req:
        raise HTTPException(status_code=404, detail="Requirement not found")

    if payload.code is not None: req.code = payload.code
    if payload.name is not None: req.name = payload.name
    if payload.requirement_type is not None: req.requirement_type = payload.requirement_type
    if payload.description is not None: req.description = payload.description
    if payload.structured_rule is not None: req.structured_rule = payload.structured_rule
    if payload.approval_status is not None:
        req.approval_status = payload.approval_status
        req.approving_officer_id = user.id
        req.approved_at = datetime.now(timezone.utc)
    if payload.officer_notes is not None: req.officer_notes = payload.officer_notes

    db.commit()
    db.refresh(req)

    log_audit_event(
        db,
        action="REQUIREMENT_MODIFIED",
        entity_type="TENDER_REQUIREMENT",
        entity_id=str(req.id),
        user_id=user.id,
        username=user.username,
        details={"code": req.code, "status": req.approval_status}
    )
    return req

@router.post("/{id}/requirements/{req_id}/approve", response_model=TenderRequirementOut)
def approve_requirement(
    id: int,
    req_id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    req = db.query(TenderRequirement).filter(
        TenderRequirement.id == req_id,
        TenderRequirement.tender_id == id
    ).first()
    if not req:
        raise HTTPException(status_code=404, detail="Requirement not found")

    req.approval_status = "APPROVED"
    req.approving_officer_id = user.id
    req.approved_at = datetime.now(timezone.utc)
    req.officer_notes = f"Formally verified and approved by {user.full_name} ({user.role})."
    db.commit()

    log_audit_event(
        db,
        action="REQUIREMENT_APPROVED",
        entity_type="TENDER_REQUIREMENT",
        entity_id=str(req.id),
        user_id=user.id,
        username=user.username,
        details={"code": req.code}
    )
    return req

@router.post("/{id}/requirements/{req_id}/reject", response_model=TenderRequirementOut)
def reject_requirement(
    id: int,
    req_id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    req = db.query(TenderRequirement).filter(
        TenderRequirement.id == req_id,
        TenderRequirement.tender_id == id
    ).first()
    if not req:
        raise HTTPException(status_code=404, detail="Requirement not found")

    req.approval_status = "REJECTED"
    req.approving_officer_id = user.id
    req.approved_at = datetime.now(timezone.utc)
    req.officer_notes = f"Rejected / excluded by {user.full_name} ({user.role})."
    db.commit()

    log_audit_event(
        db,
        action="REQUIREMENT_REJECTED",
        entity_type="TENDER_REQUIREMENT",
        entity_id=str(req.id),
        user_id=user.id,
        username=user.username,
        details={"code": req.code}
    )
    return req

@router.post("/{id}/bidders/{bidder_id}/analyze")
def analyze_bidder(
    id: int,
    bidder_id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    tb = db.query(TenderBidder).filter(
        TenderBidder.tender_id == id,
        TenderBidder.bidder_id == bidder_id
    ).first()
    if not tb:
        raise HTTPException(status_code=404, detail="Bidder is not associated with this tender")

    # Step 1: Run OCR on all active documents
    from app.models.entities import BidderDocument
    docs = db.query(BidderDocument).filter(
        BidderDocument.bidder_id == bidder_id,
        BidderDocument.is_active == True
    ).all()

    for d in docs:
        try:
            run_ocr_for_document(db, d.id, user.id, user.username)
        except Exception:
            pass

    # Step 2: Run Verification for all active documents
    for d in docs:
        try:
            run_verification_for_document(db, d.id, user.id, user.username)
        except Exception:
            pass

    # Step 3: Run Deterministic Compliance Rule Engine
    comp = evaluate_compliance(db, id, bidder_id)

    # Step 4: Run 8-Dimensional Risk Engine
    risk = calculate_bidder_risk(db, id, bidder_id)

    log_audit_event(
        db,
        action="ANALYSIS_RUN",
        entity_type="TENDER_BIDDER",
        entity_id=f"{id}:{bidder_id}",
        user_id=user.id,
        username=user.username,
        details={
            "compliance_score": comp["compliance_score"],
            "risk_category": risk["overall_category"],
            "risk_score": risk["overall_score"]
        }
    )

    return {
        "tender_id": id,
        "bidder_id": bidder_id,
        "compliance": comp,
        "risk": risk
    }

@router.post("/{id}/bidders/{bidder_id}/decision")
def record_officer_decision(
    id: int,
    bidder_id: int,
    payload: OfficerDecisionRequest,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    tb = db.query(TenderBidder).filter(
        TenderBidder.tender_id == id,
        TenderBidder.bidder_id == bidder_id
    ).first()
    if not tb:
        raise HTTPException(status_code=404, detail="Tender-bidder record not found")

    tb.final_decision = payload.decision
    tb.decision_notes = payload.decision_notes
    tb.decided_by_id = user.id
    tb.decided_at = datetime.now(timezone.utc)
    db.commit()

    # Create immutable audit record
    log_audit_event(
        db,
        action=f"OFFICER_DECISION_{payload.decision}",
        entity_type="TENDER_BIDDER",
        entity_id=f"{id}:{bidder_id}",
        user_id=user.id,
        username=user.username,
        details={
            "decision": payload.decision,
            "decision_notes": payload.decision_notes,
            "compliance_status": tb.compliance_status,
            "risk_level": tb.risk_level
        }
    )

    return {
        "message": f"Procurement Officer decision recorded: {payload.decision}",
        "decision": tb.final_decision,
        "decision_notes": tb.decision_notes,
        "decided_at": tb.decided_at
    }

@router.get("/{id}/compliance-matrix")
def get_compliance_matrix(id: int, db: Session = Depends(get_db)):
    tender = db.query(Tender).filter(Tender.id == id).first()
    if not tender:
        raise HTTPException(status_code=404, detail="Tender not found")

    reqs = db.query(TenderRequirement).filter(TenderRequirement.tender_id == id).all()
    tbs = db.query(TenderBidder).filter(TenderBidder.tender_id == id).all()

    matrix = []
    for tb in tbs:
        b = tb.bidder
        evals = db.query(ComplianceResult).filter(ComplianceResult.tender_bidder_id == tb.id).all()
        eval_map = {e.rule_code: {"status": e.status, "explanation": e.explanation} for e in evals}
        matrix.append({
            "bidder_id": b.id,
            "legal_name": b.legal_name,
            "compliance_score": tb.compliance_score,
            "compliance_status": tb.compliance_status,
            "risk_level": tb.risk_level,
            "final_decision": tb.final_decision,
            "evaluations": eval_map
        })

    return {
        "tender_id": id,
        "requirements": [{"code": r.code, "name": r.name, "type": r.requirement_type} for r in reqs],
        "matrix": matrix
    }

@router.get("/{id}/evidence")
def get_tender_evidence(id: int, db: Session = Depends(get_db)):
    evs = db.query(EvidenceRecord).filter(EvidenceRecord.tender_id == id).order_by(EvidenceRecord.id.desc()).all()
    return evs
