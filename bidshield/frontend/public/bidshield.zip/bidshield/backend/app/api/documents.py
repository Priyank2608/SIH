import hashlib
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Response, status
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.entities import BidderDocument, OCRResult, VerificationResult, Bidder
from app.schemas.schemas import BidderDocumentOut, OCRResultOut, VerificationResultOut
from app.core.security import get_current_user, AuthenticatedUser
from app.services.ocr_service import run_ocr_for_document
from app.services.verification_service import run_verification_for_document
from app.services.audit_service import log_audit_event

router = APIRouter(prefix="/documents", tags=["Documents"])

@router.get("", response_model=List[BidderDocumentOut])
def list_documents(
    tender_id: Optional[int] = None,
    bidder_id: Optional[int] = None,
    document_type: Optional[str] = None,
    active_only: bool = False,
    db: Session = Depends(get_db)
):
    query = db.query(BidderDocument)
    if tender_id: query = query.filter(BidderDocument.tender_id == tender_id)
    if bidder_id: query = query.filter(BidderDocument.bidder_id == bidder_id)
    if document_type: query = query.filter(BidderDocument.document_type == document_type.upper())
    if active_only: query = query.filter(BidderDocument.is_active == True)

    docs = query.order_by(BidderDocument.id.desc()).all()
    out = []
    for d in docs:
        ocr = db.query(OCRResult).filter(OCRResult.document_id == d.id).first()
        verif = db.query(VerificationResult).filter(VerificationResult.document_id == d.id).first()
        out.append({
            "id": d.id,
            "bidder_id": d.bidder_id,
            "tender_id": d.tender_id,
            "document_type": d.document_type,
            "filename": d.filename,
            "mime_type": d.mime_type,
            "file_hash": d.file_hash,
            "file_size_bytes": d.file_size_bytes,
            "version": d.version,
            "is_active": d.is_active,
            "previous_version_id": d.previous_version_id,
            "is_synthetic": d.is_synthetic,
            "created_at": d.created_at,
            "ocr_confidence": ocr.confidence if ocr else None,
            "verification_status": verif.status if verif else "PENDING",
            "verification_notes": verif.discrepancy_notes if verif else None
        })
    return out

@router.get("/{id}")
def get_document_details(id: int, db: Session = Depends(get_db)):
    doc = db.query(BidderDocument).filter(BidderDocument.id == id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    ocr = db.query(OCRResult).filter(OCRResult.document_id == doc.id).first()
    verif = db.query(VerificationResult).filter(VerificationResult.document_id == doc.id).first()

    # Get version history
    versions = db.query(BidderDocument).filter(
        BidderDocument.bidder_id == doc.bidder_id,
        BidderDocument.document_type == doc.document_type
    ).order_by(BidderDocument.version.asc()).all()

    return {
        "document": {
            "id": doc.id,
            "bidder_id": doc.bidder_id,
            "bidder_name": doc.bidder.legal_name if doc.bidder else "Unknown",
            "tender_id": doc.tender_id,
            "document_type": doc.document_type,
            "filename": doc.filename,
            "mime_type": doc.mime_type,
            "file_hash": doc.file_hash,
            "file_size_bytes": doc.file_size_bytes,
            "version": doc.version,
            "is_active": doc.is_active,
            "previous_version_id": doc.previous_version_id,
            "is_synthetic": doc.is_synthetic,
            "created_at": doc.created_at
        },
        "ocr": ocr,
        "verification": verif,
        "versions": [
            {
                "id": v.id,
                "version": v.version,
                "is_active": v.is_active,
                "filename": v.filename,
                "created_at": v.created_at
            }
            for v in versions
        ]
    }

@router.get("/{id}/file")
def stream_document_file(id: int, db: Session = Depends(get_db)):
    doc = db.query(BidderDocument).filter(BidderDocument.id == id).first()
    if not doc or not doc.content_bytes:
        raise HTTPException(status_code=404, detail="Document binary not found")

    return Response(
        content=doc.content_bytes,
        media_type=doc.mime_type or "application/pdf",
        headers={"Content-Disposition": f"inline; filename={doc.filename}"}
    )

@router.post("/{id}/ocr", response_model=OCRResultOut)
def trigger_ocr(
    id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    try:
        return run_ocr_for_document(db, id, user.id, user.username)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OCR execution failed: {str(e)}")

@router.post("/{id}/verify", response_model=VerificationResultOut)
def trigger_verify(
    id: int,
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    try:
        return run_verification_for_document(db, id, user.id, user.username)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Verification failed: {str(e)}")

@router.post("/upload")
async def upload_document(
    bidder_id: int = Form(...),
    document_type: str = Form(...),
    tender_id: Optional[int] = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: AuthenticatedUser = Depends(get_current_user)
):
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    file_hash = hashlib.sha256(content).hexdigest()
    doc_type_clean = document_type.strip().upper()

    # Check for existing document of this type for bidder
    existing_docs = db.query(BidderDocument).filter(
        BidderDocument.bidder_id == bidder_id,
        BidderDocument.document_type == doc_type_clean
    ).order_by(BidderDocument.version.desc()).all()

    version = 1
    prev_id = None
    if existing_docs:
        # Mark all previous versions as inactive but preserve them completely
        for ed in existing_docs:
            ed.is_active = False
        version = existing_docs[0].version + 1
        prev_id = existing_docs[0].id

    new_doc = BidderDocument(
        bidder_id=bidder_id,
        tender_id=tender_id,
        document_type=doc_type_clean,
        filename=file.filename or f"{doc_type_clean}_doc.pdf",
        mime_type=file.content_type or "application/pdf",
        file_hash=file_hash,
        file_size_bytes=len(content),
        version=version,
        is_active=True,
        previous_version_id=prev_id,
        is_synthetic=True,
        content_bytes=content
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)

    # Immediately run OCR & verification on the newly uploaded document
    run_ocr_for_document(db, new_doc.id, user.id, user.username)
    run_verification_for_document(db, new_doc.id, user.id, user.username)

    log_audit_event(
        db,
        action="DOCUMENT_UPLOADED",
        entity_type="DOCUMENT",
        entity_id=str(new_doc.id),
        user_id=user.id,
        username=user.username,
        details={
            "document_type": doc_type_clean,
            "version": version,
            "superseded_previous": bool(prev_id)
        }
    )

    return {
        "message": f"Document uploaded successfully as version {version}",
        "document_id": new_doc.id,
        "version": version,
        "file_hash": file_hash
    }
