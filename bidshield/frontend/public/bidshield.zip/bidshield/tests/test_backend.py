import pytest
from fastapi.testclient import TestClient
import sys, os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "backend")))

from app.main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["demo_mode"] == True

def test_auth_flow():
    # Invalid password
    bad_res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "WrongPassword"})
    assert bad_res.status_code == 401

    # Valid login
    res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "BidShield@123"})
    assert res.status_code == 200
    token_data = res.json()
    assert "access_token" in token_data
    token = token_data["access_token"]

    # Test me endpoint
    me_res = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_res.status_code == 200
    assert me_res.json()["username"] == "officer"

def test_tenders_and_requirements():
    res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "BidShield@123"})
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # List tenders
    t_res = client.get("/api/v1/tenders")
    assert t_res.status_code == 200
    tenders = t_res.json()
    assert len(tenders) >= 5

    # Get tender 1
    t1_res = client.get(f"/api/v1/tenders/{tenders[0]['id']}")
    assert t1_res.status_code == 200
    t1 = t1_res.json()
    assert len(t1["requirements"]) >= 4
    assert len(t1["bidders"]) == 10

    # Add custom requirement
    add_req_res = client.post(
        f"/api/v1/tenders/{t1['id']}/requirements",
        json={
            "code": "CYBER-001",
            "name": "ISO 27001 Information Security Certification",
            "requirement_type": "TECHNICAL",
            "description": "Bidder must possess valid ISO 27001 certificate."
        },
        headers=headers
    )
    assert add_req_res.status_code == 200
    new_req_id = add_req_res.json()["id"]

    # Approve requirement
    appr_res = client.post(f"/api/v1/tenders/{t1['id']}/requirements/{new_req_id}/approve", headers=headers)
    assert appr_res.status_code == 200
    assert appr_res.json()["approval_status"] == "APPROVED"

def test_bidders_360_and_documents():
    b_res = client.get("/api/v1/bidders")
    assert b_res.status_code == 200
    bidders = b_res.json()
    assert len(bidders) == 10

    # Bidder 360
    b1_res = client.get(f"/api/v1/bidders/{bidders[0]['id']}")
    assert b1_res.status_code == 200
    b1 = b1_res.json()
    assert len(b1["documents"]) >= 6
    assert len(b1["contracts"]) >= 2
    assert b1["compliance_summary"] is not None

    # Stream document file
    doc_id = b1["documents"][0]["id"]
    file_res = client.get(f"/api/v1/documents/{doc_id}/file")
    assert file_res.status_code == 200
    assert file_res.headers["content-type"] == "application/pdf"
    assert file_res.content.startswith(b"%PDF")

def test_ocr_and_verification():
    res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "BidShield@123"})
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    docs_res = client.get("/api/v1/documents")
    docs = docs_res.json()
    assert len(docs) >= 60

    doc_id = docs[0]["id"]
    ocr_res = client.post(f"/api/v1/documents/{doc_id}/ocr", headers=headers)
    assert ocr_res.status_code == 200
    assert "confidence" in ocr_res.json()

    verif_res = client.post(f"/api/v1/documents/{doc_id}/verify", headers=headers)
    assert verif_res.status_code == 200
    assert "status" in verif_res.json()

def test_reports_generation_and_download():
    res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "BidShield@123"})
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    tenders = client.get("/api/v1/tenders").json()
    tender_id = tenders[0]["id"]
    bidders = client.get("/api/v1/bidders").json()
    bidder_id = bidders[0]["id"]

    # Report 1: Quick List
    r1_res = client.post("/api/v1/reports/quick-list", json={"tender_id": tender_id}, headers=headers)
    assert r1_res.status_code == 200
    r1 = r1_res.json()
    assert r1["report_type"] == "QUICK_LIST"

    # Report 2: Detailed Assessment
    r2_res = client.post("/api/v1/reports/detailed-assessment", json={"tender_id": tender_id, "bidder_id": bidder_id}, headers=headers)
    assert r2_res.status_code == 200
    r2 = r2_res.json()
    assert r2["report_type"] == "DETAILED_ASSESSMENT"

    # Download Report 2
    dl_res = client.get(f"/api/v1/reports/{r2['report_uid']}/download")
    assert dl_res.status_code == 200
    assert dl_res.content.startswith(b"%PDF")
    assert "X-Report-SHA256" in dl_res.headers

def test_officer_decision_and_audit():
    res = client.post("/api/v1/auth/login", json={"username": "officer", "password": "BidShield@123"})
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    tenders = client.get("/api/v1/tenders").json()
    tender_id = tenders[0]["id"]
    bidders = client.get("/api/v1/bidders").json()
    bidder_id = bidders[0]["id"]

    dec_res = client.post(
        f"/api/v1/tenders/{tender_id}/bidders/{bidder_id}/decision",
        json={"decision": "ACCEPTED", "decision_notes": "All technical and financial criteria verified genuine."},
        headers=headers
    )
    assert dec_res.status_code == 200
    assert dec_res.json()["decision"] == "ACCEPTED"

    # Check audit log
    audit_res = client.get("/api/v1/audit?limit=10")
    assert audit_res.status_code == 200
    logs = audit_res.json()
    assert len(logs) > 0
    actions = [l["action"] for l in logs]
    assert any("OFFICER_DECISION" in a for a in actions)

def test_dashboard():
    dash_res = client.get("/api/v1/dashboard")
    assert dash_res.status_code == 200
    dash = dash_res.json()
    assert dash["active_tenders"] >= 5
    assert dash["total_bidders"] == 10
    assert "risk_distribution" in dash
