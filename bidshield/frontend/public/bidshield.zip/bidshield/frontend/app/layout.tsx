import type { Metadata } from 'next';
import './globals.css';
import Navbar from '../components/Navbar';

export const metadata: Metadata = {
  title: 'BidShield • AI GeM Bid Compliance Verification Platform',
  description: 'AI-Powered Integrated Bid Compliance Verification Platform for GeM Procurement (SIH26100)',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        {children}
      </body>
    </html>
  );
}
