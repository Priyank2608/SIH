'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setToken } from '../../lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('officer');
  const [password, setPassword] = useState('BidShield@123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setToken(res.access_token);
      localStorage.setItem('bidshield_user', JSON.stringify(res.user));
      router.push('/');
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = (user: string, pass: string) => {
    setUsername(user);
    setPassword(pass);
  };

  return (
    <div className="login-page-bg">
      <div className="login-card-container">
        <div className="login-header">
          <div className="login-shield-badge">🛡️</div>
          <h1>BIDSHIELD</h1>
          <p className="login-sub">GeM Bid Compliance Verification Platform</p>
          <div className="login-tag">SIH26100 • Procurement Authority Portal</div>
        </div>

        {error && <div className="alert alert-danger mb-4">{error}</div>}

        <form onSubmit={handleLogin} className="login-form">
          <div className="form-group">
            <label className="form-label" htmlFor="username">Officer Username / ID</label>
            <input
              id="username"
              type="text"
              className="form-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label" htmlFor="password">Security Credentials / Password</label>
            <input
              id="password"
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary w-full btn-login-submit" disabled={loading}>
            {loading ? 'Authenticating with GeM Security Gate...' : 'Sign In as Authorized Officer →'}
          </button>
        </form>

        <div className="demo-credentials-box">
          <span className="demo-cred-title">Demo Access Credentials:</span>
          <div className="demo-cred-buttons">
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={() => handleFillDemo('officer', 'BidShield@123')}
            >
              Procurement Officer (officer)
            </button>
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={() => handleFillDemo('auditor', 'BidShield@123')}
            >
              Vigilance Auditor (auditor)
            </button>
            <button
              type="button"
              className="btn btn-sm btn-outline"
              onClick={() => handleFillDemo('admin', 'BidShield@123')}
            >
              System Admin (admin)
            </button>
          </div>
        </div>

        <div className="login-footer-disclaimer">
          <i>Notice: Access strictly restricted to authorized Government e-Marketplace procurement evaluation personnel. Unauthorized access is prohibited under the IT Act.</i>
        </div>
      </div>
    </div>
  );
}
