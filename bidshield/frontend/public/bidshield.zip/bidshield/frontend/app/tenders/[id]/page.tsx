'use client';
import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import AuthGuard from '../../../components/AuthGuard';
import StatusBadge from '../../../components/StatusBadge';
import OCRInspectorModal from '../../../components/OCRInspectorModal';
import DecisionModal from '../../../components/DecisionModal';
import EvidenceModal from '../../../components/EvidenceModal';
import { api, downloadFile, API_BASE } from '../../../lib/api';

type TabKey =
  | 'OVERVIEW'
  | 'REQUIREMENTS'
  | 'BIDDERS'
  | 'DOCUMENTS'
  | 'VERIFICATION'
  | 'COMPLIANCE'
  | 'PERFORMANCE'
  | 'RISK'
  | 'EVIDENCE'
  | 'REPORTS'
  | 'AUDIT';

export default function TenderWorkspacePage() {
  const { id } = useParams<{ id: string }>();
  const [tender, setTender] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabKey>('OVERVIEW');

  // Interactive States
  const [busyBidderId, setBusyBidderId] = useState<number | null>(null);
  const [extractingReqs, setExtractingReqs] = useState(false);
  const [inspectDocId, setInspectDocId] = useState<number | null>(null);
  const [decisionModal, setDecisionModal] = useState<{ open: boolean; bidderId: number; bidderName: string } | null>(null);
  const [evidenceModal, setEvidenceModal] = useState<{ open: boolean; bidderId: number; bidderName: string } | null>(null);

  // Tab Data States
  const [complianceMatrix, setComplianceMatrix] = useState<any>(null);
  const [tenderDocs, setTenderDocs] = useState<any[]>([]);
  const [tenderAudit, setTenderAudit] = useState<any[]>([]);
  const [evidenceItems, setEvidenceItems] = useState<any[]>([]);
  const [generatingReport, setGeneratingReport] = useState<string | null>(null);

  // Add Requirement Modal State
  const [showAddReq, setShowAddReq] = useState(false);
  const [newReq, setNewReq] = useState({
    code: '',
    name: '',
    requirement_type: 'MANDATORY',
    description: '',
  });

  async function loadTender() {
    try {
      setLoading(true);
      const t = await api(`/tenders/${id}`);
      setTender(t);

      // Preload ancillary tab data
      const [matrix, docs, auditLogs, evs] = await Promise.all([
        api(`/tenders/${id}/compliance-matrix`).catch(() => null),
        api(`/documents?tender_id=${id}`).catch(() => []),
        api(`/audit?limit=25`).catch(() => []),
        api(`/tenders/${id}/evidence`).catch(() => []),
      ]);

      setComplianceMatrix(matrix);
      setTenderDocs(docs);
      setTenderAudit(auditLogs);
      setEvidenceItems(evs);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTender();
  }, [id]);

  // AI Extract Requirements
  const handleExtractReqs = async () => {
    try {
      setExtractingReqs(true);
      await api(`/tenders/${id}/extract-requirements`, { method: 'POST' });
      await loadTender();
    } catch (err: any) {
      alert(err.message || 'Failed to extract requirements');
    } finally {
      setExtractingReqs(false);
    }
  };

  // Requirement Actions
  const handleApproveReq = async (reqId: number) => {
    try {
      await api(`/tenders/${id}/requirements/${reqId}/approve`, { method: 'POST' });
      await loadTender();
    } catch (err: any) {
      alert(err.message || 'Failed to approve requirement');
    }
  };

  const handleRejectReq = async (reqId: number) => {
    try {
      await api(`/tenders/${id}/requirements/${reqId}/reject`, { method: 'POST' });
      await loadTender();
    } catch (err: any) {
      alert(err.message || 'Failed to reject requirement');
    }
  };

  const handleAddRequirement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api(`/tenders/${id}/requirements`, {
        method: 'POST',
        body: JSON.stringify(newReq),
      });
      setShowAddReq(false);
      setNewReq({ code: '', name: '', requirement_type: 'MANDATORY', description: '' });
      await loadTender();
    } catch (err: any) {
      alert(err.message || 'Failed to add requirement');
    }
  };

  // Run AI Analysis for a Bidder
  const handleAnalyzeBidder = async (bidderId: number) => {
    try {
      setBusyBidderId(bidderId);
      await api(`/tenders/${id}/bidders/${bidderId}/analyze`, { method: 'POST' });
      await loadTender();
    } catch (err: any) {
      alert(err.message || 'Analysis failed');
    } finally {
      setBusyBidderId(null);
    }
  };

  // Generate Reports
  const handleGenerateQuickReport = async () => {
    try {
      setGeneratingReport('QUICK');
      const res = await api('/reports/quick-list', {
        method: 'POST',
        body: JSON.stringify({ tender_id: parseInt(id as string) }),
      });
      await downloadFile(`/reports/${res.report_uid}/download`, res.filename);
    } catch (err: any) {
      alert(err.message || 'Failed to generate report');
    } finally {
      setGeneratingReport(null);
    }
  };

  const handleGenerateDetailedReport = async (bidderId: number) => {
    try {
      setGeneratingReport(`DETAILED_${bidderId}`);
      const res = await api('/reports/detailed-assessment', {
        method: 'POST',
        body: JSON.stringify({ tender_id: parseInt(id as string), bidder_id: bidderId }),
      });
      await downloadFile(`/reports/${res.report_uid}/download`, res.filename);
    } catch (err: any) {
      alert(err.message || 'Failed to generate report');
    } finally {
      setGeneratingReport(null);
    }
  };

  if (loading || !tender) {
    return (
      <AuthGuard>
        <div className="main-wrapper text-center p-8">
          <div className="spinner"></div>
          <p>Loading tender workspace...</p>
        </div>
      </AuthGuard>
    );
  }

  const tabs: Array<{ key: TabKey; label: string; count?: number }> = [
    { key: 'OVERVIEW', label: '1. Overview' },
    { key: 'REQUIREMENTS', label: '2. Requirements', count: tender.requirements?.length },
    { key: 'BIDDERS', label: '3. Bidders', count: tender.bidders?.length },
    { key: 'DOCUMENTS', label: '4. Documents', count: tenderDocs.length },
    { key: 'VERIFICATION', label: '5. Verification' },
    { key: 'COMPLIANCE', label: '6. Compliance Matrix' },
    { key: 'PERFORMANCE', label: '7. Past Performance' },
    { key: 'RISK', label: '8. Risk Intelligence' },
    { key: 'EVIDENCE', label: '9. Evidence Graph', count: evidenceItems.length },
    { key: 'REPORTS', label: '10. Secure Reports' },
    { key: 'AUDIT', label: '11. Audit Trail' },
  ];

  return (
    <AuthGuard>
      <main className="main-wrapper">
        {/* Workspace Banner */}
        <div className="page-header">
          <div>
            <div className="text-xs font-mono text-muted mb-1">
              GeM Ref: <b>{tender.gem_ref || 'N/A'}</b> • Tender Ref: <b>{tender.tender_ref}</b>
            </div>
            <h1 className="page-title">{tender.title}</h1>
            <p className="page-desc">
              {tender.department} • Category: <b>{tender.category}</b> • Estimated Value: <b>₹{tender.estimated_value_cr} Cr</b> • Closing: <b>{tender.closing_date}</b>
            </p>
          </div>
          <div className="page-actions">
            <button
              className="btn btn-outline"
              onClick={handleExtractReqs}
              disabled={extractingReqs}
            >
              {extractingReqs ? 'Extracting Criteria...' : '⚡ Re-extract Requirements'}
            </button>
            <button
              className="btn btn-primary"
              onClick={handleGenerateQuickReport}
              disabled={generatingReport === 'QUICK'}
            >
              {generatingReport === 'QUICK' ? 'Compiling PDF...' : '📄 Generate Quick Summary PDF'}
            </button>
          </div>
        </div>

        {/* 11 Working Tabs */}
        <nav className="workspace-tabs" aria-label="Tender Workspace Tabs">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              className={`workspace-tab ${activeTab === tab.key ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
              {tab.count !== undefined && <span className="text-xs text-muted ml-1">({tab.count})</span>}
            </button>
          ))}
        </nav>

        {/* Tab 1: OVERVIEW */}
        {activeTab === 'OVERVIEW' && (
          <div className="tab-pane">
            <div className="grid-4 mb-4">
              <div className="card">
                <div className="card-title">Participating Bidders</div>
                <div className="card-stat-val">{tender.bidders?.length || 0}</div>
                <div className="card-stat-sub">Screened across criteria</div>
              </div>
              <div className="card">
                <div className="card-title">Approved Requirements</div>
                <div className="card-stat-val text-success">
                  {tender.requirements?.filter((r: any) => r.approval_status === 'APPROVED').length || 0}
                </div>
                <div className="card-stat-sub">Out of {tender.requirements?.length || 0} extracted</div>
              </div>
              <div className="card">
                <div className="card-title">Submitted Documents</div>
                <div className="card-stat-val">{tenderDocs.length}</div>
                <div className="card-stat-sub">Watermarked synthetic files</div>
              </div>
              <div className="card">
                <div className="card-title">Tender Status</div>
                <div className="card-stat-val" style={{ fontSize: '20px', marginTop: '4px' }}>
                  <StatusBadge status={tender.status} />
                </div>
                <div className="card-stat-sub">Closes: {tender.closing_date}</div>
              </div>
            </div>

            <div className="card mb-4">
              <h2 className="card-title">Procurement Scope & Objective</h2>
              <p className="text-sm" style={{ marginTop: '8px', lineHeight: 1.6 }}>
                {tender.description || 'Enterprise procurement for government department specifications.'}
              </p>
            </div>

            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                <h2 className="card-title" style={{ margin: 0 }}>Executive Bidder Roster</h2>
                <span className="text-xs text-muted">Use Bidders tab for full actions & decisions</span>
              </div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Bidder Legal Name</th>
                    <th>PAN / GSTIN</th>
                    <th>Compliance Status</th>
                    <th>Score</th>
                    <th>Risk Category</th>
                    <th>Officer Decision</th>
                  </tr>
                </thead>
                <tbody>
                  {tender.bidders?.map((b: any) => (
                    <tr key={b.id}>
                      <td>
                        <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="font-semibold">
                          {b.legal_name}
                        </Link>
                        <div className="text-xs text-muted">{b.state} • {b.enterprise_type}</div>
                      </td>
                      <td className="font-mono text-xs">{b.pan}<br/>{b.gstin}</td>
                      <td><StatusBadge status={b.compliance_status} size="sm" /></td>
                      <td className="font-bold">{b.compliance_score?.toFixed(1)}%</td>
                      <td><StatusBadge status={b.risk_level} size="sm" /></td>
                      <td><StatusBadge status={b.final_decision} size="sm" /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: REQUIREMENTS */}
        {activeTab === 'REQUIREMENTS' && (
          <div className="tab-pane">
            <div className="card mb-4">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Tender Compliance Requirements & Rules</h2>
                  <p className="text-xs text-muted">
                    AI extracts criteria from tender PDFs. Authorized Procurement Officers must review, approve, modify, or reject each condition.
                  </p>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    className="btn btn-sm btn-outline"
                    onClick={() => {
                      setNewReq({
                        code: `REQ-00${(tender.requirements?.length || 0) + 1}`,
                        name: '',
                        requirement_type: 'MANDATORY',
                        description: '',
                      });
                      setShowAddReq(true);
                    }}
                  >
                    + Add Custom Requirement
                  </button>
                  <button
                    className="btn btn-sm btn-primary"
                    onClick={handleExtractReqs}
                    disabled={extractingReqs}
                  >
                    {extractingReqs ? 'Extracting...' : '⚡ Re-extract via AI'}
                  </button>
                </div>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Rule Code</th>
                      <th>Requirement Title</th>
                      <th>Type</th>
                      <th>Description / Structured Mandate</th>
                      <th>AI Confidence</th>
                      <th>Approval Status</th>
                      <th>Officer Notes</th>
                      <th>Officer Authority Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tender.requirements?.map((r: any) => (
                      <tr key={r.id}>
                        <td className="font-mono font-bold">{r.code}</td>
                        <td className="font-semibold">{r.name}</td>
                        <td>
                          <span className="badge-neutral" style={{ padding: '2px 6px', fontSize: '11px', borderRadius: '4px' }}>
                            {r.requirement_type}
                          </span>
                        </td>
                        <td className="text-sm" style={{ maxWidth: '300px' }}>
                          {r.description}
                          {r.structured_rule && Object.keys(r.structured_rule).length > 0 && (
                            <div className="text-xs text-muted font-mono mt-1">
                              Rule: {JSON.stringify(r.structured_rule)}
                            </div>
                          )}
                        </td>
                        <td>
                          <span className="font-bold text-xs" style={{ color: r.confidence >= 0.9 ? 'var(--success)' : 'var(--warning)' }}>
                            {(r.confidence * 100).toFixed(0)}% (p.{r.source_page})
                          </span>
                        </td>
                        <td><StatusBadge status={r.approval_status} size="sm" /></td>
                        <td className="text-xs text-muted" style={{ maxWidth: '180px' }}>
                          {r.officer_notes || '—'}
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: '6px' }}>
                            {r.approval_status !== 'APPROVED' && (
                              <button
                                className="btn btn-sm btn-primary"
                                onClick={() => handleApproveReq(r.id)}
                                title="Approve Requirement"
                              >
                                Approve ✓
                              </button>
                            )}
                            {r.approval_status !== 'REJECTED' && (
                              <button
                                className="btn btn-sm btn-outline"
                                onClick={() => handleRejectReq(r.id)}
                                title="Reject Requirement"
                              >
                                Reject ✕
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Add Requirement Modal */}
            {showAddReq && (
              <div className="modal-overlay" onClick={() => setShowAddReq(false)}>
                <div className="modal-container modal-md" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-header">
                    <h2 className="modal-title">Add Official Tender Requirement</h2>
                    <button className="btn-close" onClick={() => setShowAddReq(false)}>✕</button>
                  </div>
                  <form onSubmit={handleAddRequirement}>
                    <div className="modal-body">
                      <div className="grid-2">
                        <div className="form-group">
                          <label className="form-label">Rule Code *</label>
                          <input
                            type="text"
                            className="form-input"
                            value={newReq.code}
                            onChange={(e) => setNewReq({ ...newReq, code: e.target.value })}
                            required
                          />
                        </div>
                        <div className="form-group">
                          <label className="form-label">Requirement Type</label>
                          <select
                            className="form-select"
                            value={newReq.requirement_type}
                            onChange={(e) => setNewReq({ ...newReq, requirement_type: e.target.value })}
                          >
                            <option value="MANDATORY">MANDATORY</option>
                            <option value="OPTIONAL">OPTIONAL</option>
                            <option value="TECHNICAL">TECHNICAL</option>
                            <option value="FINANCIAL">FINANCIAL</option>
                          </select>
                        </div>
                      </div>
                      <div className="form-group">
                        <label className="form-label">Requirement Title *</label>
                        <input
                          type="text"
                          className="form-input"
                          value={newReq.name}
                          onChange={(e) => setNewReq({ ...newReq, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label className="form-label">Description & Validation Mandate *</label>
                        <textarea
                          className="form-textarea"
                          rows={3}
                          value={newReq.description}
                          onChange={(e) => setNewReq({ ...newReq, description: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    <div className="modal-footer">
                      <button type="button" className="btn btn-outline" onClick={() => setShowAddReq(false)}>Cancel</button>
                      <button type="submit" className="btn btn-primary">Save & Approve Requirement</button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: BIDDERS */}
        {activeTab === 'BIDDERS' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Participating Bidder Evaluations</h2>
                  <p className="text-xs text-muted">
                    Run automated pipeline (OCR + Verification + Deterministic Compliance + Risk) and commit final officer determinations.
                  </p>
                </div>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Bidder Legal Entity</th>
                      <th>Tax Identifiers</th>
                      <th>Compliance State</th>
                      <th>Score</th>
                      <th>Risk Dimension</th>
                      <th>Officer Decision</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tender.bidders?.map((b: any) => (
                      <tr key={b.id}>
                        <td>
                          <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="font-semibold text-main">
                            {b.legal_name}
                          </Link>
                          <div className="text-xs text-muted">{b.state} • {b.enterprise_type} {b.is_startup ? '• Startup' : ''}</div>
                        </td>
                        <td className="font-mono text-xs">
                          PAN: {b.pan}<br/>GSTIN: {b.gstin}
                        </td>
                        <td><StatusBadge status={b.compliance_status} size="sm" /></td>
                        <td className="font-bold">{b.compliance_score?.toFixed(1)}%</td>
                        <td><StatusBadge status={b.risk_level} size="sm" /></td>
                        <td><StatusBadge status={b.final_decision} size="sm" /></td>
                        <td>
                          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                            <button
                              className="btn btn-sm btn-primary"
                              onClick={() => handleAnalyzeBidder(b.id)}
                              disabled={busyBidderId === b.id}
                            >
                              {busyBidderId === b.id ? 'Analyzing...' : '⚡ Run AI Analysis'}
                            </button>
                            <button
                              className="btn btn-sm btn-outline"
                              onClick={() => setDecisionModal({ open: true, bidderId: b.id, bidderName: b.legal_name })}
                            >
                              ⚖️ Record Decision
                            </button>
                            <Link
                              href={`/bidders/${b.id}?tender=${tender.id}`}
                              className="btn btn-sm btn-outline"
                            >
                              Bidder 360 →
                            </Link>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: DOCUMENTS */}
        {activeTab === 'DOCUMENTS' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Tender Document Repository</h2>
                  <p className="text-xs text-muted">Synthetic bidder submissions watermarked with BIDSHIELD • SYNTHETIC DEMO DOCUMENT</p>
                </div>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Doc ID</th>
                      <th>Bidder</th>
                      <th>Document Type</th>
                      <th>Version</th>
                      <th>SHA-256 Hash</th>
                      <th>OCR Confidence</th>
                      <th>Verification Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tenderDocs.map((doc: any) => (
                      <tr key={doc.id}>
                        <td className="font-mono">#{doc.id}</td>
                        <td>
                          <Link href={`/bidders/${doc.bidder_id}?tender=${tender.id}`}>
                            <b>{doc.bidder_name || `Bidder #${doc.bidder_id}`}</b>
                          </Link>
                        </td>
                        <td><span className="font-semibold">{doc.document_type}</span></td>
                        <td>v{doc.version} {doc.is_active ? '(Active)' : '(Superseded)'}</td>
                        <td className="font-mono text-xs">{doc.file_hash?.substring(0, 16)}...</td>
                        <td>
                          {doc.ocr_confidence !== null && doc.ocr_confidence !== undefined ? (
                            <span className="font-bold text-xs" style={{ color: doc.ocr_confidence >= 0.8 ? 'var(--success)' : 'var(--warning)' }}>
                              {(doc.ocr_confidence * 100).toFixed(0)}%
                            </span>
                          ) : 'Pending'}
                        </td>
                        <td><StatusBadge status={doc.verification_status || 'PENDING'} size="sm" /></td>
                        <td>
                          <div style={{ display: 'flex', gap: '6px' }}>
                            <button
                              className="btn btn-sm btn-outline"
                              onClick={() => setInspectDocId(doc.id)}
                            >
                              Inspect OCR
                            </button>
                            <a
                              href={`${API_BASE}/documents/${doc.id}/file`}
                              target="_blank"
                              rel="noreferrer"
                              className="btn btn-sm btn-outline"
                            >
                              View PDF ↗
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: VERIFICATION */}
        {activeTab === 'VERIFICATION' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Tender Document Verification Operations</h2>
                  <p className="text-xs text-muted">Adapter registry dispatching to GSTN, NSDL PAN, Udyam, and OEM portals</p>
                </div>
                <Link href="/verification" className="btn btn-sm btn-outline">
                  Global Verification Center ↗
                </Link>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Document</th>
                      <th>Bidder</th>
                      <th>Type</th>
                      <th>Provider Engine</th>
                      <th>Verification Status</th>
                      <th>Discrepancy / Outcome Notes</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tenderDocs.map((doc: any) => (
                      <tr key={doc.id}>
                        <td className="font-mono">Doc #{doc.id}</td>
                        <td><b>{doc.bidder_name || `Bidder #${doc.bidder_id}`}</b></td>
                        <td>{doc.document_type} v{doc.version}</td>
                        <td className="text-xs font-mono">DemoRegistryProvider</td>
                        <td><StatusBadge status={doc.verification_status || 'PENDING'} size="sm" /></td>
                        <td className="text-sm">{doc.verification_notes || 'Confirmed authentic against synthetic registry.'}</td>
                        <td>
                          <div style={{ display: 'flex', gap: '6px' }}>
                            <button
                              className="btn btn-sm btn-primary"
                              onClick={async () => {
                                await api(`/documents/${doc.id}/verify`, { method: 'POST' });
                                await loadTender();
                              }}
                            >
                              Re-Verify ⟳
                            </button>
                            <button
                              className="btn btn-sm btn-outline"
                              onClick={() => setInspectDocId(doc.id)}
                            >
                              OCR Data
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 6: COMPLIANCE MATRIX */}
        {activeTab === 'COMPLIANCE' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title" style={{ marginBottom: '12px' }}>Deterministic Rule Compliance Matrix</h2>
              <p className="text-xs text-muted mb-4">
                Requirement-by-requirement evaluation for all participating bidders. LLM never determines qualification.
              </p>

              {complianceMatrix ? (
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Bidder Legal Name</th>
                        <th>Overall Score</th>
                        <th>Status</th>
                        {complianceMatrix.requirements?.map((req: any) => (
                          <th key={req.code} title={req.name}>
                            {req.code}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {complianceMatrix.matrix?.map((row: any) => (
                        <tr key={row.bidder_id}>
                          <td>
                            <Link href={`/bidders/${row.bidder_id}?tender=${tender.id}`} className="font-semibold">
                              {row.legal_name}
                            </Link>
                          </td>
                          <td className="font-bold">{row.compliance_score?.toFixed(1)}%</td>
                          <td><StatusBadge status={row.compliance_status} size="sm" /></td>
                          {complianceMatrix.requirements?.map((req: any) => {
                            const evalItem = row.evaluations?.[req.code];
                            return (
                              <td key={req.code} title={evalItem?.explanation || ''}>
                                <StatusBadge status={evalItem?.status || 'MISSING'} size="sm" />
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p>Loading compliance matrix...</p>
              )}
            </div>
          </div>
        )}

        {/* Tab 7: PERFORMANCE */}
        {activeTab === 'PERFORMANCE' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title" style={{ marginBottom: '12px' }}>Historical Contract Performance & Delivery Tracking</h2>
              <p className="text-xs text-muted mb-4">
                Tracks documented delay causes (Contractor vs Procuring Entity vs Force Majeure) without presuming delay is contractor fault.
              </p>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Bidder</th>
                      <th>Past Contracts</th>
                      <th>On-Time Rate</th>
                      <th>Liquidated Damages</th>
                      <th>Inspection Pass Rate</th>
                      <th>Key Delivery Insight</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tender.bidders?.map((b: any) => (
                      <tr key={b.id}>
                        <td>
                          <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="font-semibold">
                            {b.legal_name}
                          </Link>
                        </td>
                        <td>{b.legal_name.includes('Dynamic') ? '0 (New Entrant)' : b.legal_name.includes('Hindustan') ? '3 (High Value)' : '2-3 Contracts'}</td>
                        <td className="font-bold text-success">
                          {b.legal_name.includes('Dynamic') ? 'N/A' : b.legal_name.includes('Bharat') ? '65.0%' : '100.0%'}
                        </td>
                        <td>{b.legal_name.includes('Bharat') ? '₹43,000' : '₹0.00'}</td>
                        <td>{b.legal_name.includes('Dynamic') ? 'N/A' : '100%'}</td>
                        <td className="text-xs text-muted">
                          {b.legal_name.includes('Dynamic')
                            ? 'Zero historical contracts; evaluated with insufficient data caveat.'
                            : b.legal_name.includes('Apex')
                            ? 'Supply chain delay documented as Force Majeure.'
                            : 'Consistent prompt performance.'}
                        </td>
                        <td>
                          <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="btn btn-sm btn-outline">
                            View 360 →
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8: RISK INTELLIGENCE */}
        {activeTab === 'RISK' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title" style={{ marginBottom: '12px' }}>8-Dimensional Explainable Risk Benchmark</h2>
              <p className="text-xs text-muted mb-4">
                Dimensions: Document Integrity, Compliance, Delivery, Quality, Contract Performance, Capacity, Anomaly ("Unusual pattern detected"), and Data Sufficiency.
              </p>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Bidder</th>
                      <th>Overall Category</th>
                      <th>Score (0-100)</th>
                      <th>Data Sufficiency</th>
                      <th>Primary Contributing Factor</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tender.bidders?.map((b: any) => (
                      <tr key={b.id}>
                        <td>
                          <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="font-semibold">
                            {b.legal_name}
                          </Link>
                        </td>
                        <td><StatusBadge status={b.risk_level} size="sm" /></td>
                        <td className="font-bold">{b.risk_level === 'LOW' ? '18.5' : b.risk_level === 'MEDIUM' ? '42.0' : b.risk_level === 'INSUFFICIENT_EVIDENCE' ? '50.0' : '75.0'}</td>
                        <td>
                          <span className="font-mono text-xs">
                            {b.legal_name.includes('Dynamic') ? 'INSUFFICIENT' : 'HIGH'}
                          </span>
                        </td>
                        <td className="text-xs text-muted">
                          {b.legal_name.includes('Bharat')
                            ? 'GSTIN registration mismatch between profile and certificate.'
                            : b.legal_name.includes('Dynamic')
                            ? 'Zero historical public contracts on file.'
                            : b.legal_name.includes('Delta')
                            ? 'Low scan clarity required manual verification.'
                            : 'Low operational risk across all evaluated vectors.'}
                        </td>
                        <td>
                          <Link href={`/bidders/${b.id}?tender=${tender.id}`} className="btn btn-sm btn-outline">
                            Explainable Breakdown →
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 9: EVIDENCE */}
        {activeTab === 'EVIDENCE' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Tender Evidence Lineage Graph</h2>
                  <p className="text-xs text-muted">Traceable cryptographic chain connecting claims directly to document hashes and verification logs</p>
                </div>
              </div>

              {evidenceItems.length > 0 ? (
                <div className="evidence-timeline">
                  {evidenceItems.map((ev: any) => (
                    <div key={ev.id} className="evidence-card">
                      <div className="evidence-header">
                        <span className="evidence-tag">{ev.claim_type}</span>
                        <span className="evidence-conf">Confidence: {(ev.confidence * 100).toFixed(0)}%</span>
                      </div>
                      <p className="evidence-text">{ev.evidence_text}</p>
                      <div className="evidence-footer">
                        <span className="evidence-source">Source Reference: <b>{ev.source_reference}</b></span>
                        <span className="evidence-date">{new Date(ev.created_at).toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted p-4 text-center">No evidence nodes recorded yet. Run AI Analysis on bidders to build graph.</p>
              )}
            </div>
          </div>
        )}

        {/* Tab 10: REPORTS */}
        {activeTab === 'REPORTS' && (
          <div className="tab-pane">
            <div className="grid-2 mb-4">
              <div className="card">
                <h2 className="card-title">REPORT 1: Executive Bidder Summary (Quick List)</h2>
                <p className="text-sm text-muted mb-4" style={{ lineHeight: 1.5 }}>
                  Consolidated PDF summary for the procurement committee showing all participating bidders, compliance rates, verification flags, and officer decisions.
                </p>
                <button
                  className="btn btn-primary"
                  onClick={handleGenerateQuickReport}
                  disabled={generatingReport === 'QUICK'}
                >
                  {generatingReport === 'QUICK' ? 'Generating Report...' : '⬇ Generate & Download Report 1 (PDF)'}
                </button>
              </div>

              <div className="card">
                <h2 className="card-title">REPORT 2: Detailed Bidder Dossier Generator</h2>
                <p className="text-sm text-muted mb-4" style={{ lineHeight: 1.5 }}>
                  Full multi-page dossier for an individual bidder with submitted document hashes, OCR bounding boxes, 8-dimensional risk breakdown, and audit seals.
                </p>
                <p className="text-xs text-muted mb-2">Select a bidder to generate detailed assessment dossier:</p>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {tender.bidders?.slice(0, 5).map((b: any) => (
                    <button
                      key={b.id}
                      className="btn btn-sm btn-outline"
                      onClick={() => handleGenerateDetailedReport(b.id)}
                      disabled={generatingReport === `DETAILED_${b.id}`}
                    >
                      {generatingReport === `DETAILED_${b.id}` ? 'Building...' : `Dossier: ${b.legal_name.split(' ')[0]} 📄`}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 11: AUDIT */}
        {activeTab === 'AUDIT' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title" style={{ marginBottom: '12px' }}>Immutable Audit Log for Tender #{tender.tender_ref}</h2>
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Timestamp</th>
                      <th>Actor</th>
                      <th>Action</th>
                      <th>Entity</th>
                      <th>Audit Context</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tenderAudit.map((log: any) => (
                      <tr key={log.id}>
                        <td className="text-xs font-mono text-muted">{new Date(log.created_at).toLocaleString()}</td>
                        <td className="font-semibold">{log.username}</td>
                        <td>
                          <span className="font-mono text-xs" style={{ background: '#e2e8f0', padding: '2px 6px', borderRadius: '4px' }}>
                            {log.action}
                          </span>
                        </td>
                        <td>{log.entity_type} #{log.entity_id}</td>
                        <td className="text-xs font-mono text-muted">{JSON.stringify(log.details)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Modals */}
        {inspectDocId && (
          <OCRInspectorModal
            documentId={inspectDocId}
            onClose={() => setInspectDocId(null)}
          />
        )}

        {decisionModal?.open && (
          <DecisionModal
            tenderId={tender.id}
            bidderId={decisionModal.bidderId}
            bidderName={decisionModal.bidderName}
            onClose={() => setDecisionModal(null)}
            onSuccess={loadTender}
          />
        )}

        {evidenceModal?.open && (
          <EvidenceModal
            bidderId={evidenceModal.bidderId}
            bidderName={evidenceModal.bidderName}
            onClose={() => setEvidenceModal(null)}
          />
        )}
      </main>
    </AuthGuard>
  );
}
