'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AuthGuard from '../../components/AuthGuard';
import StatusBadge from '../../components/StatusBadge';
import { api } from '../../lib/api';

export default function TendersListPage() {
  const [tenders, setTenders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTender, setNewTender] = useState({
    tender_ref: '',
    gem_ref: '',
    title: '',
    department: '',
    category: 'IT Equipment & Hardware',
    estimated_value_cr: 1.0,
    issue_date: '2026-09-25',
    closing_date: '2026-10-31',
    description: '',
  });
  const [creating, setCreating] = useState(false);

  async function loadTenders() {
    try {
      setLoading(true);
      const data = await api('/tenders');
      setTenders(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTenders();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setCreating(true);
      await api('/tenders', {
        method: 'POST',
        body: JSON.stringify(newTender),
      });
      setShowCreateModal(false);
      await loadTenders();
    } catch (err: any) {
      alert(err.message || 'Failed to create tender');
    } finally {
      setCreating(false);
    }
  };

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">GeM Tenders Workspace</h1>
            <p className="page-desc">
              Manage GeM procurement tenders, review extracted requirements, and monitor bidder compliance dossiers.
            </p>
          </div>
          <div className="page-actions">
            <button
              className="btn btn-primary"
              onClick={() => {
                setNewTender({
                  tender_ref: `GEM/2026/B/00${Math.floor(10000 + Math.random() * 90000)}`,
                  gem_ref: `GEM-REF-${Math.floor(10000 + Math.random() * 90000)}`,
                  title: '',
                  department: 'Ministry of Communications',
                  category: 'IT Equipment & Hardware',
                  estimated_value_cr: 5.0,
                  issue_date: '2026-09-25',
                  closing_date: '2026-11-15',
                  description: 'Tender procurement for IT infrastructure and hardware.',
                });
                setShowCreateModal(true);
              }}
            >
              + Create / Upload GeM Tender
            </button>
          </div>
        </div>

        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading procurement tenders...</p>
          </div>
        ) : (
          <div className="card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Tender Reference</th>
                    <th>GeM Ref</th>
                    <th>Tender Title & Scope</th>
                    <th>Procuring Ministry / Department</th>
                    <th>Est. Value</th>
                    <th>Closing Date</th>
                    <th>Requirements</th>
                    <th>Bidders</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {tenders.map((t) => (
                    <tr key={t.id}>
                      <td className="font-mono font-semibold">
                        <Link href={`/tenders/${t.id}`}>{t.tender_ref}</Link>
                      </td>
                      <td className="font-mono text-xs text-muted">{t.gem_ref || 'N/A'}</td>
                      <td>
                        <Link href={`/tenders/${t.id}`} className="font-semibold text-main">
                          {t.title}
                        </Link>
                        <div className="text-xs text-muted">{t.category}</div>
                      </td>
                      <td>{t.department}</td>
                      <td className="font-semibold">₹{t.estimated_value_cr} Cr</td>
                      <td className="text-sm">{t.closing_date}</td>
                      <td>
                        <span className="badge-neutral" style={{ padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
                          {t.requirements?.length || 0} Criteria
                        </span>
                      </td>
                      <td>
                        <span className="badge-neutral" style={{ padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
                          {t.bidders_count || 10} Bidders
                        </span>
                      </td>
                      <td><StatusBadge status={t.status} size="sm" /></td>
                      <td>
                        <Link href={`/tenders/${t.id}`} className="btn btn-sm btn-primary">
                          Open Workspace →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Create Tender Modal */}
        {showCreateModal && (
          <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
            <div className="modal-container modal-md" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <div>
                  <div className="modal-pretitle">Tender Management</div>
                  <h2 className="modal-title">Publish New GeM Tender</h2>
                </div>
                <button className="btn-close" onClick={() => setShowCreateModal(false)}>✕</button>
              </div>

              <form onSubmit={handleCreate}>
                <div className="modal-body">
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">Tender Reference ID *</label>
                      <input
                        type="text"
                        className="form-input"
                        value={newTender.tender_ref}
                        onChange={(e) => setNewTender({ ...newTender, tender_ref: e.target.value })}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">GeM Portal Reference</label>
                      <input
                        type="text"
                        className="form-input"
                        value={newTender.gem_ref}
                        onChange={(e) => setNewTender({ ...newTender, gem_ref: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Tender Title *</label>
                    <input
                      type="text"
                      className="form-input"
                      value={newTender.title}
                      onChange={(e) => setNewTender({ ...newTender, title: e.target.value })}
                      placeholder="e.g. Supply of Advanced Workstations and IT Hardware"
                      required
                    />
                  </div>

                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">Ministry / Department *</label>
                      <input
                        type="text"
                        className="form-input"
                        value={newTender.department}
                        onChange={(e) => setNewTender({ ...newTender, department: e.target.value })}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Procurement Category</label>
                      <select
                        className="form-select"
                        value={newTender.category}
                        onChange={(e) => setNewTender({ ...newTender, category: e.target.value })}
                      >
                        <option value="IT Equipment & Hardware">IT Equipment & Hardware</option>
                        <option value="Cloud & Cybersecurity Services">Cloud & Cybersecurity Services</option>
                        <option value="Medical Devices & Hospital Equipment">Medical Devices & Hospital Equipment</option>
                        <option value="Heavy Electrical & Power Equipment">Heavy Electrical & Power Equipment</option>
                        <option value="Solar & Renewable Energy">Solar & Renewable Energy</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">Estimated Value (INR Crores) *</label>
                      <input
                        type="number"
                        step="0.1"
                        className="form-input"
                        value={newTender.estimated_value_cr}
                        onChange={(e) => setNewTender({ ...newTender, estimated_value_cr: parseFloat(e.target.value) || 1.0 })}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Bid Closing Date *</label>
                      <input
                        type="date"
                        className="form-input"
                        value={newTender.closing_date}
                        onChange={(e) => setNewTender({ ...newTender, closing_date: e.target.value })}
                        required
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Scope & Statutory Conditions</label>
                    <textarea
                      className="form-textarea"
                      rows={3}
                      value={newTender.description}
                      onChange={(e) => setNewTender({ ...newTender, description: e.target.value })}
                      placeholder="Specify requirements like GST, PAN, OEM Authorization, Make in India local content..."
                    />
                    <span className="form-hint">AI Document Engine will automatically extract initial compliance rules from this scope.</span>
                  </div>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn btn-outline" onClick={() => setShowCreateModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary" disabled={creating}>
                    {creating ? 'Extracting Requirements...' : 'Publish Tender & Extract Criteria'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </AuthGuard>
  );
}
