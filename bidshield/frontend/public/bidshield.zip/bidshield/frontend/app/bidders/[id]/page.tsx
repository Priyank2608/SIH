'use client';
import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import AuthGuard from '../../../components/AuthGuard';
import StatusBadge from '../../../components/StatusBadge';
import OCRInspectorModal from '../../../components/OCRInspectorModal';
import EvidenceModal from '../../../components/EvidenceModal';
import { api, downloadFile, API_BASE } from '../../../lib/api';

type BidderTabKey =
  | 'IDENTITY'
  | 'REGISTRATIONS'
  | 'DOCUMENTS'
  | 'OCR'
  | 'VERIFICATION'
  | 'COMPLIANCE'
  | 'CONTRACTS'
  | 'DELIVERY'
  | 'QUALITY'
  | 'RISK'
  | 'EVIDENCE'
  | 'AUDIT';

export default function Bidder360Page() {
  const { id } = useParams<{ id: string }>();
  const searchParams = useSearchParams();
  const tenderId = searchParams.get('tender') || '1';

  const [bidder, setBidder] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<BidderTabKey>('IDENTITY');

  // Modals
  const [inspectDocId, setInspectDocId] = useState<number | null>(null);
  const [showEvidenceModal, setShowEvidenceModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadDocType, setUploadDocType] = useState('UDYAM');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  // Report generation state
  const [generatingReport, setGeneratingReport] = useState(false);

  // Performance Data
  const [performance, setPerformance] = useState<any>(null);
  const [riskData, setRiskData] = useState<any>(null);
  const [evidenceList, setEvidenceList] = useState<any[]>([]);
  const [auditList, setAuditList] = useState<any[]>([]);

  async function loadBidder() {
    try {
      setLoading(true);
      const b = await api(`/bidders/${id}?tender=${tenderId}`);
      setBidder(b);

      const [perf, risk, evs, audits] = await Promise.all([
        api(`/bidders/${id}/performance?tender=${tenderId}`).catch(() => null),
        api(`/bidders/${id}/risk?tender=${tenderId}`).catch(() => null),
        api(`/bidders/${id}/evidence`).catch(() => []),
        api(`/bidders/${id}/audit`).catch(() => []),
      ]);

      setPerformance(perf);
      setRiskData(risk);
      setEvidenceList(evs);
      setAuditList(audits);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBidder();
  }, [id, tenderId]);

  // Handle Upload Corrected Document Version
  const handleUploadVersion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile) {
      alert('Please select a PDF file to upload.');
      return;
    }

    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('bidder_id', id as string);
      formData.append('tender_id', tenderId);
      formData.append('document_type', uploadDocType);
      formData.append('file', uploadFile);

      await api('/documents/upload', {
        method: 'POST',
        body: formData,
      });

      setShowUploadModal(false);
      setUploadFile(null);
      await loadBidder();
      alert(`Corrected version of ${uploadDocType} uploaded successfully. Version history preserved.`);
    } catch (err: any) {
      alert(err.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  // Generate Report 2 (Detailed Bidder Assessment)
  const handleGenerateDossier = async () => {
    try {
      setGeneratingReport(true);
      const res = await api('/reports/detailed-assessment', {
        method: 'POST',
        body: JSON.stringify({
          tender_id: parseInt(tenderId),
          bidder_id: parseInt(id as string),
        }),
      });
      await downloadFile(`/reports/${res.report_uid}/download`, res.filename);
    } catch (err: any) {
      alert(err.message || 'Failed to generate dossier PDF');
    } finally {
      setGeneratingReport(false);
    }
  };

  if (loading || !bidder) {
    return (
      <AuthGuard>
        <div className="main-wrapper text-center p-8">
          <div className="spinner"></div>
          <p>Loading Bidder 360 profile...</p>
        </div>
      </AuthGuard>
    );
  }

  const tabs: Array<{ key: BidderTabKey; label: string }> = [
    { key: 'IDENTITY', label: '1. Identity' },
    { key: 'REGISTRATIONS', label: '2. Registrations' },
    { key: 'DOCUMENTS', label: `3. Documents (${bidder.documents?.length || 0})` },
    { key: 'OCR', label: '4. OCR & AI Fields' },
    { key: 'VERIFICATION', label: '5. Verification' },
    { key: 'COMPLIANCE', label: '6. Compliance' },
    { key: 'CONTRACTS', label: `7. Contracts (${bidder.contracts?.length || 0})` },
    { key: 'DELIVERY', label: '8. Delivery & Delays' },
    { key: 'QUALITY', label: '9. Quality & Defects' },
    { key: 'RISK', label: '10. Risk (8-Dim)' },
    { key: 'EVIDENCE', label: `11. Evidence (${evidenceList.length})` },
    { key: 'AUDIT', label: '12. Audit Trail' },
  ];

  return (
    <AuthGuard>
      <main className="main-wrapper">
        {/* Bidder 360 Header */}
        <div className="page-header">
          <div>
            <div className="text-xs font-mono text-muted mb-1">
              Bidder ID: <b>#{bidder.id}</b> • PAN: <b>{bidder.pan}</b> • GSTIN: <b>{bidder.gstin}</b>
            </div>
            <h1 className="page-title">{bidder.legal_name}</h1>
            <p className="page-desc">
              {bidder.trade_name ? `Trading as: ${bidder.trade_name} • ` : ''}
              {bidder.enterprise_type} Enterprise • Location: <b>{bidder.district}, {bidder.state}</b>
            </p>
          </div>
          <div className="page-actions">
            <button
              className="btn btn-outline"
              onClick={() => setShowUploadModal(true)}
            >
              + Upload Corrected Document Version
            </button>
            <button
              className="btn btn-outline"
              onClick={() => setShowEvidenceModal(true)}
            >
              🔗 View Evidence Graph
            </button>
            <button
              className="btn btn-primary"
              onClick={handleGenerateDossier}
              disabled={generatingReport}
            >
              {generatingReport ? 'Compiling Dossier...' : '📄 Generate Detailed Dossier PDF'}
            </button>
          </div>
        </div>

        {/* 12 Working Tabs */}
        <nav className="workspace-tabs" aria-label="Bidder 360 Tabs">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              className={`workspace-tab ${activeTab === tab.key ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Tab 1: IDENTITY */}
        {activeTab === 'IDENTITY' && (
          <div className="tab-pane">
            <div className="grid-2">
              <div className="card">
                <h2 className="card-title">Corporate Entity Particulars</h2>
                <table className="data-table mt-2">
                  <tbody>
                    <tr><td className="font-semibold">Legal Enterprise Name:</td><td>{bidder.legal_name}</td></tr>
                    <tr><td className="font-semibold">Trade Name:</td><td>{bidder.trade_name || 'N/A'}</td></tr>
                    <tr><td className="font-semibold">Corporate Identity (CIN):</td><td className="font-mono">{bidder.cin || 'N/A'}</td></tr>
                    <tr><td className="font-semibold">Date of Incorporation:</td><td>{bidder.incorporation_date || '2016-04-12'}</td></tr>
                    <tr><td className="font-semibold">Enterprise Category:</td><td>{bidder.enterprise_type}</td></tr>
                    <tr>
                      <td className="font-semibold">DPIIT Startup Status:</td>
                      <td>
                        {bidder.is_startup ? (
                          <span className="badge-success" style={{ padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
                            Recognized DPIIT Startup
                          </span>
                        ) : 'Not Registered as Startup'}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="card">
                <h2 className="card-title">Registered Office & Authorized Contacts</h2>
                <table className="data-table mt-2">
                  <tbody>
                    <tr><td className="font-semibold">Registered Address:</td><td>{bidder.address}</td></tr>
                    <tr><td className="font-semibold">District:</td><td>{bidder.district}</td></tr>
                    <tr><td className="font-semibold">State:</td><td>{bidder.state}</td></tr>
                    <tr><td className="font-semibold">Authorized Representative:</td><td><b>{bidder.contact_person}</b></td></tr>
                    <tr><td className="font-semibold">Official Contact Email:</td><td>{bidder.contact_email}</td></tr>
                    <tr><td className="font-semibold">Official Phone Number:</td><td>{bidder.contact_phone}</td></tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: REGISTRATIONS */}
        {activeTab === 'REGISTRATIONS' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title mb-4">Statutory Government Registrations</h2>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Registration Authority</th>
                    <th>Identifier / Reg Number</th>
                    <th>Registered Status</th>
                    <th>Seeding / Validity</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><b>Goods and Services Tax (GSTN)</b></td>
                    <td className="font-mono font-bold">{bidder.gstin}</td>
                    <td><StatusBadge status="VERIFIED" size="sm" /></td>
                    <td>Regular Taxpayer • Active</td>
                    <td><span className="text-xs text-muted">Verified via Demo GSTN API</span></td>
                  </tr>
                  <tr>
                    <td><b>Income Tax Department (PAN)</b></td>
                    <td className="font-mono font-bold">{bidder.pan}</td>
                    <td><StatusBadge status="VERIFIED" size="sm" /></td>
                    <td>Operative • Aadhaar Seeded</td>
                    <td><span className="text-xs text-muted">Verified via Demo NSDL API</span></td>
                  </tr>
                  <tr>
                    <td><b>Ministry of MSME (Udyam)</b></td>
                    <td className="font-mono font-bold">{bidder.udyam_number || 'N/A'}</td>
                    <td><StatusBadge status={bidder.udyam_number ? 'VERIFIED' : 'PENDING'} size="sm" /></td>
                    <td>{bidder.enterprise_type} • Valid</td>
                    <td><span className="text-xs text-muted">Verified via Demo MSME Adapter</span></td>
                  </tr>
                  <tr>
                    <td><b>Ministry of Corporate Affairs (MCA)</b></td>
                    <td className="font-mono font-bold">{bidder.cin || 'N/A'}</td>
                    <td><StatusBadge status="VERIFIED" size="sm" /></td>
                    <td>Active RoC Registration</td>
                    <td><span className="text-xs text-muted">Verified via Demo MCA Adapter</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: DOCUMENTS */}
        {activeTab === 'DOCUMENTS' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Document Version Repository</h2>
                  <p className="text-xs text-muted">
                    Full version history. Corrected document versions (v2) supersede earlier versions (v1) without deleting previous records.
                  </p>
                </div>
                <button
                  className="btn btn-sm btn-primary"
                  onClick={() => setShowUploadModal(true)}
                >
                  + Upload New Version
                </button>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Doc ID</th>
                      <th>Type</th>
                      <th>Filename</th>
                      <th>Version</th>
                      <th>Status Flag</th>
                      <th>SHA-256 Hash</th>
                      <th>OCR Confidence</th>
                      <th>Verification Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bidder.documents?.map((d: any) => (
                      <tr key={d.id} style={{ opacity: d.is_active ? 1 : 0.65 }}>
                        <td className="font-mono">#{d.id}</td>
                        <td><span className="font-bold">{d.document_type}</span></td>
                        <td>{d.filename}</td>
                        <td>
                          v{d.version} {d.is_active ? (
                            <span className="badge-success text-xs" style={{ padding: '1px 5px', borderRadius: '3px' }}>Active</span>
                          ) : (
                            <span className="badge-neutral text-xs" style={{ padding: '1px 5px', borderRadius: '3px' }}>Superseded</span>
                          )}
                        </td>
                        <td><span className="badge-demo text-xs">SYNTHETIC</span></td>
                        <td className="font-mono text-xs">{d.file_hash?.substring(0, 16)}...</td>
                        <td>
                          {d.ocr_confidence !== null ? (
                            <span className="font-bold text-xs" style={{ color: d.ocr_confidence >= 0.8 ? 'var(--success)' : 'var(--warning)' }}>
                              {(d.ocr_confidence * 100).toFixed(0)}%
                            </span>
                          ) : 'Pending'}
                        </td>
                        <td><StatusBadge status={d.verification_status || 'PENDING'} size="sm" /></td>
                        <td>
                          <div style={{ display: 'flex', gap: '6px' }}>
                            <button
                              className="btn btn-sm btn-outline"
                              onClick={() => setInspectDocId(d.id)}
                            >
                              Inspect OCR
                            </button>
                            <a
                              href={`${API_BASE}/documents/${d.id}/file`}
                              target="_blank"
                              rel="noreferrer"
                              className="btn btn-sm btn-outline"
                            >
                              View PDF ↗
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: OCR */}
        {activeTab === 'OCR' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title mb-2">OCR & Document AI Field Extractions</h2>
              <p className="text-xs text-muted mb-4">
                Inspect structured text and key-value fields extracted from submitted PDF documents.
              </p>
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Document</th>
                      <th>Type</th>
                      <th>Version</th>
                      <th>Extraction Confidence</th>
                      <th>OCR Engine</th>
                      <th>Inspect Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bidder.documents?.map((d: any) => (
                      <tr key={d.id}>
                        <td className="font-mono">Doc #{d.id}</td>
                        <td className="font-bold">{d.document_type}</td>
                        <td>v{d.version}</td>
                        <td>
                          <span className="font-bold" style={{ color: (d.ocr_confidence || 0) >= 0.8 ? 'var(--success)' : 'var(--warning)' }}>
                            {d.ocr_confidence ? `${(d.ocr_confidence * 100).toFixed(1)}%` : 'Pending'}
                          </span>
                        </td>
                        <td>TesseractOCR / PyMuPDF</td>
                        <td>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => setInspectDocId(d.id)}
                          >
                            Open Side-by-Side OCR Inspector 🔍
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: VERIFICATION */}
        {activeTab === 'VERIFICATION' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title mb-2">Registry Verification Status</h2>
              <p className="text-xs text-muted mb-4">
                Automated verification checks executed against simulated government and OEM authorities.
              </p>
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Document Type</th>
                      <th>Version</th>
                      <th>Status Outcome</th>
                      <th>Discrepancy / Officer Note</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bidder.documents?.map((d: any) => (
                      <tr key={d.id}>
                        <td className="font-bold">{d.document_type}</td>
                        <td>v{d.version}</td>
                        <td><StatusBadge status={d.verification_status || 'PENDING'} size="sm" /></td>
                        <td className="text-sm">{d.verification_notes || 'Authenticity verified with zero discrepancies.'}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-outline"
                            onClick={async () => {
                              await api(`/documents/${d.id}/verify`, { method: 'POST' });
                              await loadBidder();
                            }}
                          >
                            Re-verify ⟳
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 6: COMPLIANCE */}
        {activeTab === 'COMPLIANCE' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Deterministic Rule Compliance Evaluation</h2>
                  <p className="text-xs text-muted">Evaluated against active rules for Tender #{tenderId}</p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span className="text-sm">Compliance Score:</span>
                  <span className="card-stat-val" style={{ fontSize: '24px' }}>
                    {bidder.compliance_summary?.score !== undefined ? `${bidder.compliance_summary.score.toFixed(1)}%` : 'N/A'}
                  </span>
                  <StatusBadge status={bidder.compliance_summary?.status || 'PENDING'} />
                </div>
              </div>

              <table className="data-table">
                <thead>
                  <tr>
                    <th>Rule Code</th>
                    <th>Requirement Name</th>
                    <th>Evaluation Status</th>
                    <th>Deterministic Explanation</th>
                  </tr>
                </thead>
                <tbody>
                  {bidder.compliance_summary?.results?.map((cr: any) => (
                    <tr key={cr.code}>
                      <td className="font-mono font-bold">{cr.code}</td>
                      <td className="font-semibold">{cr.name}</td>
                      <td><StatusBadge status={cr.status} size="sm" /></td>
                      <td className="text-sm">{cr.explanation}</td>
                    </tr>
                  )) || (
                    <tr>
                      <td colSpan={4} className="text-muted p-4 text-center">
                        Compliance evaluation pending. Run AI Analysis from Tender Workspace.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 7: CONTRACTS */}
        {activeTab === 'CONTRACTS' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title mb-2">Historical Public Procurement Contracts</h2>
              <p className="text-xs text-muted mb-4">
                Verified historical contracts executed by this bidder across central and state procuring authorities.
              </p>
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Contract Ref</th>
                      <th>Procuring Entity</th>
                      <th>Project Title</th>
                      <th>Category</th>
                      <th>Value</th>
                      <th>Scheduled Date</th>
                      <th>Actual Completion</th>
                      <th>Delays</th>
                      <th>Performance Rating</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bidder.contracts?.map((c: any) => (
                      <tr key={c.id}>
                        <td className="font-mono font-semibold">{c.contract_ref}</td>
                        <td>{c.procuring_entity}</td>
                        <td className="font-semibold">{c.title}</td>
                        <td>{c.category}</td>
                        <td>₹{c.contract_value_lakhs} Lakhs</td>
                        <td>{c.scheduled_completion}</td>
                        <td>{c.actual_completion || 'In Progress'}</td>
                        <td>
                          {c.delay_days > 0 ? (
                            <span className="text-danger font-bold">{c.delay_days} days</span>
                          ) : (
                            <span className="text-success font-semibold">On-Time</span>
                          )}
                        </td>
                        <td><b>{c.performance_rating} / 5.0</b> ⭐</td>
                      </tr>
                    ))}
                    {(!bidder.contracts || bidder.contracts.length === 0) && (
                      <tr>
                        <td colSpan={9} className="text-muted p-4 text-center">
                          Zero historical contracts recorded. (Evaluated under Insufficient Evidence rule).
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 8: DELIVERY */}
        {activeTab === 'DELIVERY' && (
          <div className="tab-pane">
            <div className="grid-3 mb-4">
              <div className="card">
                <div className="card-title">On-Time Delivery Rate</div>
                <div className="card-stat-val text-success">
                  {performance?.on_time_rate !== undefined ? `${performance.on_time_rate}%` : 'N/A'}
                </div>
                <div className="card-stat-sub">Completed without delay</div>
              </div>
              <div className="card">
                <div className="card-title">Average Delay (Days)</div>
                <div className="card-stat-val">
                  {performance?.avg_delay_days || 0}
                </div>
                <div className="card-stat-sub">Across all past orders</div>
              </div>
              <div className="card">
                <div className="card-title">Liquidated Damages Imposed</div>
                <div className="card-stat-val text-danger">
                  ₹{performance?.liquidated_damages_inr?.toLocaleString() || '0'}
                </div>
                <div className="card-stat-sub">Statutory penalty deductions</div>
              </div>
            </div>

            <div className="card">
              <h2 className="card-title mb-2">Documented Delay Cause Analysis</h2>
              <p className="text-xs text-muted mb-4">
                BidShield isolates contractor execution issues from client delays, force majeure, or statutory extensions.
              </p>
              <div className="grid-4">
                {Object.entries(performance?.delay_causes || {}).map(([cause, count]: any) => (
                  <div key={cause} className="p-3" style={{ background: '#f8fafc', borderRadius: '6px', border: '1px solid var(--border)' }}>
                    <div className="text-xs font-semibold text-muted">{cause}</div>
                    <div className="card-stat-val" style={{ fontSize: '22px', marginTop: '4px' }}>{count}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 9: QUALITY */}
        {activeTab === 'QUALITY' && (
          <div className="tab-pane">
            <div className="grid-3 mb-4">
              <div className="card">
                <div className="card-title">Third-Party Inspection Pass Rate</div>
                <div className="card-stat-val text-success">
                  {performance?.quality_metrics?.pass_rate !== undefined ? `${performance.quality_metrics.pass_rate}%` : '100%'}
                </div>
                <div className="card-stat-sub">DGQA / TPIA certified inspections</div>
              </div>
              <div className="card">
                <div className="card-title">Reported Defect Count</div>
                <div className="card-stat-val">
                  {performance?.quality_metrics?.total_defects || 0}
                </div>
                <div className="card-stat-sub">Components flagged during QA</div>
              </div>
              <div className="card">
                <div className="card-title">Warranty Complaints</div>
                <div className="card-stat-val">
                  {performance?.quality_metrics?.warranty_claims || 0}
                </div>
                <div className="card-stat-sub">Post-commissioning issues</div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 10: RISK */}
        {activeTab === 'RISK' && (
          <div className="tab-pane">
            <div className="card mb-4">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>8-Dimensional Explainable Risk Benchmark</h2>
                  <p className="text-xs text-muted">
                    Explainable AI analysis distinguishing low risk from insufficient evidence. Anomaly does not equate to fraud.
                  </p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span className="text-sm">Overall Category:</span>
                  <StatusBadge status={riskData?.overall_category || bidder.risk_summary?.overall_category || 'LOW'} />
                </div>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Risk Dimension</th>
                      <th>Score (0-100)</th>
                      <th>Contributing Factor / Rational Explanation</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries((riskData?.dimensions || bidder.risk_summary?.dimensions || {})).map(([dim, data]: any) => (
                      <tr key={dim}>
                        <td className="font-semibold">{dim.replace(/_/g, ' ')}</td>
                        <td>
                          <span className={`font-bold ${data.score >= 60 ? 'text-danger' : data.score >= 35 ? 'text-warning' : 'text-success'}`}>
                            {data.score?.toFixed(1)}
                          </span>
                        </td>
                        <td className="text-sm">{data.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 11: EVIDENCE */}
        {activeTab === 'EVIDENCE' && (
          <div className="tab-pane">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Traceable Cryptographic Evidence Trail</h2>
                  <p className="text-xs text-muted">Every verification conclusion is linked directly to source document bytes and hashes</p>
                </div>
              </div>

              <div className="evidence-timeline">
                {evidenceList.map((ev: any) => (
                  <div key={ev.id} className="evidence-card">
                    <div className="evidence-header">
                      <span className="evidence-tag">{ev.claim_type}</span>
                      <span className="evidence-conf">Confidence: {(ev.confidence * 100).toFixed(0)}%</span>
                    </div>
                    <p className="evidence-text">{ev.evidence_text}</p>
                    <div className="evidence-footer">
                      <span className="evidence-source">Source Reference: <b>{ev.source_reference}</b></span>
                      <span className="evidence-date">{new Date(ev.created_at).toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 12: AUDIT */}
        {activeTab === 'AUDIT' && (
          <div className="tab-pane">
            <div className="card">
              <h2 className="card-title mb-4">Immutable Audit Trail for {bidder.legal_name}</h2>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>Officer</th>
                    <th>Action</th>
                    <th>Entity</th>
                    <th>Metadata Details</th>
                  </tr>
                </thead>
                <tbody>
                  {auditList.map((log: any) => (
                    <tr key={log.id}>
                      <td className="font-mono text-xs text-muted">{new Date(log.created_at).toLocaleString()}</td>
                      <td className="font-semibold">{log.username}</td>
                      <td>
                        <span className="font-mono text-xs" style={{ background: '#e2e8f0', padding: '2px 6px', borderRadius: '4px' }}>
                          {log.action}
                        </span>
                      </td>
                      <td>{log.entity_type} #{log.entity_id}</td>
                      <td className="font-mono text-xs text-muted">{JSON.stringify(log.details)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modals */}
        {inspectDocId && (
          <OCRInspectorModal
            documentId={inspectDocId}
            onClose={() => setInspectDocId(null)}
          />
        )}

        {showEvidenceModal && (
          <EvidenceModal
            bidderId={bidder.id}
            bidderName={bidder.legal_name}
            onClose={() => setShowEvidenceModal(false)}
          />
        )}

        {/* Upload Corrected Version Modal */}
        {showUploadModal && (
          <div className="modal-overlay" onClick={() => setShowUploadModal(false)}>
            <div className="modal-container modal-md" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <div>
                  <div className="modal-pretitle">Document Version Control</div>
                  <h2 className="modal-title">Upload Corrected Document (Version 2)</h2>
                </div>
                <button className="btn-close" onClick={() => setShowUploadModal(false)}>✕</button>
              </div>

              <form onSubmit={handleUploadVersion}>
                <div className="modal-body">
                  <div className="officer-mandate-notice">
                    <span className="mandate-icon">ℹ</span>
                    <p>
                      <b>Version History Guarantee:</b> Uploading a new version will supersede previous certificates without deleting them. All historical OCR and verification results are permanently preserved in the audit database.
                    </p>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Document Category / Type *</label>
                    <select
                      className="form-select"
                      value={uploadDocType}
                      onChange={(e) => setUploadDocType(e.target.value)}
                    >
                      <option value="UDYAM">Udyam Registration Certificate</option>
                      <option value="GST">GST Registration Certificate</option>
                      <option value="PAN">PAN Card Certificate</option>
                      <option value="OEM">OEM Manufacturer Authorization (MAF)</option>
                      <option value="EXPERIENCE">Past Experience Certificate</option>
                      <option value="TURNOVER">CA Audited Turnover Certificate</option>
                      <option value="LOCAL_CONTENT">Make in India Local Content Declaration</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Select PDF Document File *</label>
                    <input
                      type="file"
                      accept="application/pdf"
                      className="form-input"
                      onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                      required
                    />
                    <span className="form-hint">Accepted format: PDF (Max 25MB). File hash will be cryptographically computed.</span>
                  </div>
                </div>

                <div className="modal-footer">
                  <button type="button" className="btn btn-outline" onClick={() => setShowUploadModal(false)}>
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary" disabled={uploading}>
                    {uploading ? 'Processing & Executing OCR...' : 'Upload & Verify Version 2'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </AuthGuard>
  );
}
