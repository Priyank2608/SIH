'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AuthGuard from '../../components/AuthGuard';
import { api } from '../../lib/api';

export default function BiddersListPage() {
  const [bidders, setBidders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await api('/bidders');
        setBidders(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = bidders.filter((b) =>
    b.legal_name.toLowerCase().includes(search.toLowerCase()) ||
    b.pan.toLowerCase().includes(search.toLowerCase()) ||
    b.gstin.toLowerCase().includes(search.toLowerCase()) ||
    b.state.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">Bidder 360 Repository</h1>
            <p className="page-desc">
              Internal procurement authority registry of participating corporate and MSME bidders.
            </p>
          </div>
          <div className="page-actions">
            <input
              type="text"
              placeholder="Search by legal name, PAN, GSTIN, state..."
              className="form-input"
              style={{ width: '320px' }}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading bidder database...</p>
          </div>
        ) : (
          <div className="card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Legal Enterprise Name</th>
                    <th>PAN</th>
                    <th>GSTIN</th>
                    <th>Enterprise Classification</th>
                    <th>State / Location</th>
                    <th>Authorized Contact</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((b) => (
                    <tr key={b.id}>
                      <td>
                        <Link href={`/bidders/${b.id}`} className="font-semibold text-main">
                          {b.legal_name}
                        </Link>
                        {b.trade_name && <div className="text-xs text-muted">Trading as: {b.trade_name}</div>}
                      </td>
                      <td className="font-mono">{b.pan}</td>
                      <td className="font-mono">{b.gstin}</td>
                      <td>
                        <span className="badge-neutral" style={{ padding: '2px 8px', borderRadius: '4px', fontSize: '11px' }}>
                          {b.enterprise_type}
                        </span>
                        {b.is_startup && (
                          <span style={{ marginLeft: '6px', background: '#dcfce7', color: '#166534', padding: '2px 6px', borderRadius: '4px', fontSize: '10px', fontWeight: 700 }}>
                            DPIIT STARTUP
                          </span>
                        )}
                      </td>
                      <td>{b.district}, {b.state}</td>
                      <td>
                        <div className="text-xs">
                          <b>{b.contact_person}</b><br/>
                          <span className="text-muted">{b.contact_email}</span>
                        </div>
                      </td>
                      <td>
                        <Link href={`/bidders/${b.id}`} className="btn btn-sm btn-primary">
                          Bidder 360 Dossier →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </AuthGuard>
  );
}
