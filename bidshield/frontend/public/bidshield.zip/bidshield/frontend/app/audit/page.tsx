'use client';
import React, { useState, useEffect } from 'react';
import AuthGuard from '../../components/AuthGuard';
import { api } from '../../lib/api';

export default function AuditTrailPage() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionFilter, setActionFilter] = useState('');
  const [expandedLogId, setExpandedLogId] = useState<number | null>(null);

  async function loadAuditLogs() {
    try {
      setLoading(true);
      const url = actionFilter ? `/audit?action=${encodeURIComponent(actionFilter)}&limit=100` : '/audit?limit=100';
      const data = await api(url);
      setLogs(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAuditLogs();
  }, [actionFilter]);

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">Immutable Audit Trail Explorer</h1>
            <p className="page-desc">
              Tamper-evident system log tracking every authentication event, OCR execution, verification job, requirement approval, and procurement officer decision.
            </p>
          </div>
          <div className="page-actions">
            <input
              type="text"
              placeholder="Filter by action (e.g. DECISION, OCR, VERIFICATION)..."
              className="form-input"
              style={{ width: '360px' }}
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
            />
            <button className="btn btn-outline" onClick={loadAuditLogs}>
              Refresh ⟳
            </button>
          </div>
        </div>

        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading audit ledger records...</p>
          </div>
        ) : (
          <div className="card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Log ID</th>
                    <th>Timestamp (UTC)</th>
                    <th>Officer / Actor</th>
                    <th>Action Event</th>
                    <th>Target Entity</th>
                    <th>IP Address</th>
                    <th>Context Details</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <React.Fragment key={log.id}>
                      <tr>
                        <td className="font-mono text-xs text-muted">#{log.id}</td>
                        <td className="font-mono text-xs">{new Date(log.created_at).toLocaleString()}</td>
                        <td>
                          <span className="font-semibold">{log.username}</span>
                        </td>
                        <td>
                          <span
                            className="font-mono text-xs font-bold"
                            style={{
                              background: log.action.includes('DECISION')
                                ? '#dbeafe'
                                : log.action.includes('FAILURE')
                                ? '#fee2e2'
                                : '#f1f5f9',
                              color: log.action.includes('DECISION')
                                ? '#1e40af'
                                : log.action.includes('FAILURE')
                                ? '#b91c1c'
                                : '#334155',
                              padding: '2px 8px',
                              borderRadius: '4px',
                            }}
                          >
                            {log.action}
                          </span>
                        </td>
                        <td>
                          {log.entity_type} {log.entity_id ? `(#${log.entity_id})` : ''}
                        </td>
                        <td className="font-mono text-xs text-muted">{log.ip_address}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-outline text-xs"
                            onClick={() => setExpandedLogId(expandedLogId === log.id ? null : log.id)}
                          >
                            {expandedLogId === log.id ? 'Hide Details' : 'View Payload'}
                          </button>
                        </td>
                      </tr>
                      {expandedLogId === log.id && (
                        <tr>
                          <td colSpan={7} style={{ background: '#f8fafc', padding: '12px 20px' }}>
                            <div className="text-xs font-mono text-muted mb-1">RAW JSON AUDIT RECORD PAYLOAD:</div>
                            <pre className="raw-ocr-pre" style={{ maxHeight: '180px' }}>
                              {JSON.stringify(log.details, null, 2)}
                            </pre>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                  {logs.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center text-muted p-6">
                        No audit records found matching criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </AuthGuard>
  );
}
