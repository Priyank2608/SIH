'use client';
import React, { useState, useEffect } from 'react';
import AuthGuard from '../../components/AuthGuard';
import { api, downloadFile } from '../../lib/api';

export default function ReportsArchivePage() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [downloadingUid, setDownloadingUid] = useState<string | null>(null);

  // Quick generation form states
  const [tenderId, setTenderId] = useState('1');
  const [bidderId, setBidderId] = useState('1');
  const [generating, setGenerating] = useState(false);

  async function loadReports() {
    try {
      setLoading(true);
      const data = await api('/reports');
      setReports(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadReports();
  }, []);

  const handleDownload = async (reportUid: string, filename: string) => {
    try {
      setDownloadingUid(reportUid);
      await downloadFile(`/reports/${reportUid}/download`, filename);
      await loadReports();
    } catch (err: any) {
      alert(err.message || 'Download failed');
    } finally {
      setDownloadingUid(null);
    }
  };

  const handleGenerateQuick = async () => {
    try {
      setGenerating(true);
      const res = await api('/reports/quick-list', {
        method: 'POST',
        body: JSON.stringify({ tender_id: parseInt(tenderId) }),
      });
      await loadReports();
      await downloadFile(`/reports/${res.report_uid}/download`, res.filename);
    } catch (err: any) {
      alert(err.message || 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleGenerateDetailed = async () => {
    try {
      setGenerating(true);
      const res = await api('/reports/detailed-assessment', {
        method: 'POST',
        body: JSON.stringify({
          tender_id: parseInt(tenderId),
          bidder_id: parseInt(bidderId),
        }),
      });
      await loadReports();
      await downloadFile(`/reports/${res.report_uid}/download`, res.filename);
    } catch (err: any) {
      alert(err.message || 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">Secure PDF Reports & Dossiers Archive</h1>
            <p className="page-desc">
              Authoritative, evidence-linked PDF reports generated with ReportLab and secured with SHA-256 cryptographic hashes.
            </p>
          </div>
        </div>

        {/* Report Generation Quick Console */}
        <div className="card mb-4" style={{ background: '#f8fafc' }}>
          <h2 className="card-title mb-2">On-Demand Report Generator</h2>
          <div className="grid-3" style={{ gap: '14px', alignItems: 'flex-end' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Tender ID</label>
              <select
                className="form-select"
                value={tenderId}
                onChange={(e) => setTenderId(e.target.value)}
              >
                <option value="1">Tender #1: Desktop Computers (GEM/2026/B/0012345)</option>
                <option value="2">Tender #2: Cloud Infrastructure (GEM/2026/B/0023456)</option>
                <option value="3">Tender #3: ICU Ventilators (GEM/2026/B/0034567)</option>
                <option value="4">Tender #4: Transformers & Switchgear (GEM/2026/B/0045678)</option>
                <option value="5">Tender #5: Solar PV Installation (GEM/2026/B/0056789)</option>
              </select>
            </div>

            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Bidder (For Detailed Dossier)</label>
              <select
                className="form-select"
                value={bidderId}
                onChange={(e) => setBidderId(e.target.value)}
              >
                <option value="1">Alpha Technologies Pvt Ltd (Verified Prime)</option>
                <option value="2">Bharat Systems Pvt Ltd (GSTIN Discrepancy)</option>
                <option value="3">Gamma Infotech Pvt Ltd (Udyam v1/v2)</option>
                <option value="4">Delta Digital Solutions (Low-Quality Scan)</option>
                <option value="5">Epsilon Engineering Pvt Ltd (Provider Retry)</option>
                <option value="6">Zeta Innovations Corp (Missing OEM Doc)</option>
                <option value="7">Hindustan Cloud & Networks (100% On-Time)</option>
                <option value="8">Apex Medical Systems Ltd (Supply Delay)</option>
                <option value="9">Dynamic Heavy Electricals (Startup)</option>
                <option value="10">Surya Urja Green Technologies (MII 50%)</option>
              </select>
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                className="btn btn-outline"
                onClick={handleGenerateQuick}
                disabled={generating}
              >
                Report 1: Quick List 📄
              </button>
              <button
                className="btn btn-primary"
                onClick={handleGenerateDetailed}
                disabled={generating}
              >
                Report 2: Detailed Dossier 📑
              </button>
            </div>
          </div>
        </div>

        {/* Reports Archive Table */}
        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading generated reports archive...</p>
          </div>
        ) : (
          <div className="card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Report Type</th>
                    <th>Report Filename</th>
                    <th>Tender / Bidder Scope</th>
                    <th>SHA-256 Hash</th>
                    <th>Generated Timestamp</th>
                    <th>Downloads</th>
                    <th>Secure Action</th>
                  </tr>
                </thead>
                <tbody>
                  {reports.map((rep) => (
                    <tr key={rep.report_uid}>
                      <td>
                        <span className={`status-badge ${rep.report_type === 'QUICK_LIST' ? 'badge-neutral' : 'badge-success'}`}>
                          {rep.report_type === 'QUICK_LIST' ? 'REPORT 1: SUMMARY' : 'REPORT 2: DOSSIER'}
                        </span>
                      </td>
                      <td className="font-semibold">{rep.filename}</td>
                      <td>
                        Tender #{rep.tender_id}
                        {rep.bidder_id ? ` • Bidder #${rep.bidder_id}` : ' • All Bidders'}
                      </td>
                      <td className="font-mono text-xs">{rep.file_hash?.substring(0, 20)}...</td>
                      <td className="text-xs text-muted">{new Date(rep.created_at).toLocaleString()}</td>
                      <td className="font-mono text-xs">{rep.download_count}</td>
                      <td>
                        <button
                          className="btn btn-sm btn-primary"
                          onClick={() => handleDownload(rep.report_uid, rep.filename)}
                          disabled={downloadingUid === rep.report_uid}
                        >
                          {downloadingUid === rep.report_uid ? 'Downloading...' : 'Download PDF ⬇'}
                        </button>
                      </td>
                    </tr>
                  ))}
                  {reports.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center text-muted p-6">
                        No reports generated yet. Use the on-demand console above to create Report 1 or Report 2.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </AuthGuard>
  );
}
