'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AuthGuard from '../../components/AuthGuard';
import StatusBadge from '../../components/StatusBadge';
import OCRInspectorModal from '../../components/OCRInspectorModal';
import { api, API_BASE } from '../../lib/api';

export default function VerificationControlCenterPage() {
  const [records, setRecords] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [inspectDocId, setInspectDocId] = useState<number | null>(null);
  const [busyDocId, setBusyDocId] = useState<number | null>(null);

  async function loadData() {
    try {
      setLoading(true);
      const [recData, provData] = await Promise.all([
        api(`/verification?status=${statusFilter}`),
        api('/verification/providers').catch(() => []),
      ]);
      setRecords(recData);
      setProviders(provData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, [statusFilter]);

  const handleRetry = async (documentId: number) => {
    try {
      setBusyDocId(documentId);
      await api(`/verification/${documentId}/retry`, { method: 'POST' });
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Retry failed');
    } finally {
      setBusyDocId(null);
    }
  };

  const statusOptions = [
    'ALL',
    'VERIFIED',
    'MISMATCH',
    'EXPIRED',
    'MANUAL_REVIEW',
    'RETRY_REQUIRED',
    'PENDING',
  ];

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">Verification Control Center</h1>
            <p className="page-desc">
              Manage multi-provider verification pipeline across GSTN, PAN, Udyam, and OEM gateways with real-time retry dispatch.
            </p>
          </div>
          <div className="page-actions">
            <button className="btn btn-outline" onClick={loadData}>
              Refresh State ⟳
            </button>
          </div>
        </div>

        {/* Provider Registry Strip */}
        <div className="card mb-4" style={{ background: '#f8fafc' }}>
          <h2 className="card-title mb-2">Registered Verification Providers & Adapters</h2>
          <div className="grid-3" style={{ gap: '10px' }}>
            {providers.map((p) => (
              <div key={p.provider_code} className="p-2" style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: '6px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span className="font-bold text-xs">{p.provider_name}</span>
                  <span className="badge-demo text-xs">{p.auth_type}</span>
                </div>
                <div className="text-xs text-muted font-mono mt-1">Doc: {p.document_type} • Timeout: {p.timeout_seconds}s</div>
              </div>
            ))}
          </div>
        </div>

        {/* Filter Bar */}
        <div className="card mb-4" style={{ padding: '12px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <span className="text-xs font-bold text-muted uppercase">Filter by Verification State:</span>
            {statusOptions.map((st) => (
              <button
                key={st}
                className={`btn btn-sm ${statusFilter === st ? 'btn-primary' : 'btn-outline'}`}
                onClick={() => setStatusFilter(st)}
              >
                {st.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Records Table */}
        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading verification records...</p>
          </div>
        ) : (
          <div className="card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Doc ID</th>
                    <th>Bidder Legal Entity</th>
                    <th>Document Type</th>
                    <th>Version</th>
                    <th>OCR Confidence</th>
                    <th>Provider Name</th>
                    <th>Status Outcome</th>
                    <th>Discrepancy Notes / Diagnostic</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {records.map((r) => (
                    <tr key={r.document_id}>
                      <td className="font-mono">#{r.document_id}</td>
                      <td>
                        <Link href={`/bidders/${r.bidder_id}`}>
                          <b>{r.bidder_name}</b>
                        </Link>
                      </td>
                      <td><span className="font-bold">{r.document_type}</span></td>
                      <td>v{r.version}</td>
                      <td>
                        <span className="font-bold" style={{ color: r.ocr_confidence >= 0.8 ? 'var(--success)' : 'var(--warning)' }}>
                          {(r.ocr_confidence * 100).toFixed(0)}%
                        </span>
                      </td>
                      <td className="text-xs font-mono">{r.verification_provider}</td>
                      <td><StatusBadge status={r.verification_status} size="sm" /></td>
                      <td className="text-sm" style={{ maxWidth: '280px' }}>
                        {r.discrepancy_notes || <span className="text-success text-xs">Authenticity verified</span>}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => handleRetry(r.document_id)}
                            disabled={busyDocId === r.document_id}
                          >
                            {busyDocId === r.document_id ? 'Retrying...' : 'Retry ⟳'}
                          </button>
                          <button
                            className="btn btn-sm btn-outline"
                            onClick={() => setInspectDocId(r.document_id)}
                          >
                            OCR Inspector
                          </button>
                          <a
                            href={`${API_BASE}/documents/${r.document_id}/file`}
                            target="_blank"
                            rel="noreferrer"
                            className="btn btn-sm btn-outline"
                          >
                            PDF ↗
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {records.length === 0 && (
                    <tr>
                      <td colSpan={9} className="text-center text-muted p-6">
                        No verification records found matching filter "{statusFilter}".
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {inspectDocId && (
          <OCRInspectorModal
            documentId={inspectDocId}
            onClose={() => setInspectDocId(null)}
          />
        )}
      </main>
    </AuthGuard>
  );
}
