'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AuthGuard from '../components/AuthGuard';
import StatusBadge from '../components/StatusBadge';
import OCRInspectorModal from '../components/OCRInspectorModal';
import { api } from '../lib/api';

export default function DashboardPage() {
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [inspectDocId, setInspectDocId] = useState<number | null>(null);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await api('/dashboard');
        setMetrics(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  return (
    <AuthGuard>
      <main className="main-wrapper">
        <div className="page-header">
          <div>
            <h1 className="page-title">Procurement Authority Executive Dashboard</h1>
            <p className="page-desc">
              AI-Powered Tender Verification & Compliance Overview • GeM Procurement Authority
            </p>
          </div>
          <div className="page-actions">
            <Link href="/tenders" className="btn btn-primary">
              Browse Tenders Workspace 📋
            </Link>
            <Link href="/verification" className="btn btn-outline">
              Verification Control Center 🛡️
            </Link>
          </div>
        </div>

        {loading ? (
          <div className="text-center p-8">
            <div className="spinner"></div>
            <p>Loading procurement intelligence metrics...</p>
          </div>
        ) : (
          <>
            {/* Top Stat Counters */}
            <div className="grid-4">
              <div className="card">
                <div className="card-title">Active GeM Tenders</div>
                <div className="card-stat-val">{metrics?.active_tenders || 0}</div>
                <div className="card-stat-sub">Across 5 Central Ministries</div>
              </div>
              <div className="card">
                <div className="card-title">Participating Bidders</div>
                <div className="card-stat-val">{metrics?.total_bidders || 0}</div>
                <div className="card-stat-sub">66 Synthetic Documents Analyzed</div>
              </div>
              <div className="card">
                <div className="card-title">Completed Verifications</div>
                <div className="card-stat-val text-success">{metrics?.completed_verifications || 0}</div>
                <div className="card-stat-sub">{metrics?.pending_verifications || 0} Pending / Retry</div>
              </div>
              <div className="card">
                <div className="card-title">Manual Reviews Needed</div>
                <div className="card-stat-val text-warning">{metrics?.manual_reviews_required || 0}</div>
                <div className="card-stat-sub">Mismatches / Degraded Scans</div>
              </div>
            </div>

            {/* Middle Section: Compliance Rate & Risk Distribution */}
            <div className="grid-2">
              <div className="card">
                <h2 className="card-title">Overall GeM Compliance Benchmark</h2>
                <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginTop: '12px' }}>
                  <div style={{ fontSize: '42px', fontWeight: 800, color: 'var(--primary)' }}>
                    {metrics?.overall_compliance_rate || 0}%
                  </div>
                  <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>
                    Deterministic evaluation against statutory GST, PAN, Udyam, OEM Authorization, Financial Turnover, and Class-I Make-in-India mandates.
                  </div>
                </div>
              </div>

              <div className="card">
                <h2 className="card-title">Explainable Multidimensional Risk Distribution</h2>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '10px', marginTop: '12px' }}>
                  <div className="p-2 text-center" style={{ background: '#f0fdf4', borderRadius: '6px' }}>
                    <div style={{ fontSize: '11px', color: 'var(--success)', fontWeight: 600 }}>LOW RISK</div>
                    <div style={{ fontSize: '20px', fontWeight: 800, color: 'var(--success)' }}>
                      {metrics?.risk_distribution?.LOW || 0}
                    </div>
                  </div>
                  <div className="p-2 text-center" style={{ background: '#fffbeb', borderRadius: '6px' }}>
                    <div style={{ fontSize: '11px', color: 'var(--warning)', fontWeight: 600 }}>MEDIUM</div>
                    <div style={{ fontSize: '20px', fontWeight: 800, color: 'var(--warning)' }}>
                      {metrics?.risk_distribution?.MEDIUM || 0}
                    </div>
                  </div>
                  <div className="p-2 text-center" style={{ background: '#fef2f2', borderRadius: '6px' }}>
                    <div style={{ fontSize: '11px', color: 'var(--danger)', fontWeight: 600 }}>HIGH RISK</div>
                    <div style={{ fontSize: '20px', fontWeight: 800, color: 'var(--danger)' }}>
                      {metrics?.risk_distribution?.HIGH || 0}
                    </div>
                  </div>
                  <div className="p-2 text-center" style={{ background: '#f0fdfa', borderRadius: '6px' }}>
                    <div style={{ fontSize: '11px', color: '#0f766e', fontWeight: 600 }}>NO HISTORY</div>
                    <div style={{ fontSize: '20px', fontWeight: 800, color: '#0f766e' }}>
                      {metrics?.risk_distribution?.INSUFFICIENT_EVIDENCE || 0}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Attention Documents */}
            <div className="card mb-4">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Documents Requiring Officer Scrutiny</h2>
                  <p className="text-xs text-muted">Flagged by OCR Engine, Mismatch Detection, or Provider Unavailable states</p>
                </div>
                <Link href="/verification" className="btn btn-sm btn-outline">
                  View All in Verification Center →
                </Link>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Document</th>
                      <th>Bidder</th>
                      <th>Type</th>
                      <th>Version</th>
                      <th>Status Flag</th>
                      <th>Discrepancy / Officer Note</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics?.attention_documents?.map((item: any) => (
                      <tr key={item.document_id}>
                        <td className="font-mono">Doc #{item.document_id}</td>
                        <td>
                          <Link href={`/bidders/${item.bidder_id}`}>
                            <b>{item.bidder_name}</b>
                          </Link>
                        </td>
                        <td><span className="font-semibold">{item.document_type}</span></td>
                        <td>v{item.version}</td>
                        <td><StatusBadge status={item.status} size="sm" /></td>
                        <td className="text-sm">{item.notes}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-primary"
                            onClick={() => setInspectDocId(item.document_id)}
                          >
                            Inspect OCR / Verify
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Activity Audit Logs */}
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <div>
                  <h2 className="card-title" style={{ margin: 0 }}>Recent Immutable Audit Trail</h2>
                  <p className="text-xs text-muted">Real-time log of verification runs, requirement approvals, and officer decisions</p>
                </div>
                <Link href="/audit" className="btn btn-sm btn-outline">
                  Full Audit Log Explorer →
                </Link>
              </div>

              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Timestamp</th>
                      <th>Officer / Actor</th>
                      <th>Action Event</th>
                      <th>Entity</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics?.recent_activity?.slice(0, 6).map((log: any) => (
                      <tr key={log.id}>
                        <td className="text-xs text-muted font-mono">
                          {new Date(log.created_at).toLocaleString()}
                        </td>
                        <td>
                          <span className="font-semibold">{log.username}</span>
                        </td>
                        <td>
                          <span className="font-mono text-xs" style={{ background: '#e2e8f0', padding: '2px 6px', borderRadius: '4px' }}>
                            {log.action}
                          </span>
                        </td>
                        <td>{log.entity_type} {log.entity_id ? `#${log.entity_id}` : ''}</td>
                        <td className="text-xs text-muted font-mono">
                          {JSON.stringify(log.details)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {inspectDocId && (
          <OCRInspectorModal
            documentId={inspectDocId}
            onClose={() => setInspectDocId(null)}
          />
        )}
      </main>
    </AuthGuard>
  );
}
