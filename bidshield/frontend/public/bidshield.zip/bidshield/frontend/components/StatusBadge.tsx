'use client';
import React from 'react';

interface StatusBadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export default function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const norm = (status || 'PENDING').toUpperCase();

  let className = 'badge-neutral';
  let icon = '⏳';
  let label = norm.replace(/_/g, ' ');

  switch (norm) {
    case 'VERIFIED':
    case 'PASS':
    case 'ACCEPTED':
    case 'APPROVED':
    case 'LOW':
      className = 'badge-success';
      icon = '✓';
      break;

    case 'REVIEW_REQUIRED':
    case 'MANUAL_REVIEW':
    case 'REVIEW':
    case 'CONDITIONAL':
    case 'MODIFIED':
    case 'MEDIUM':
      className = 'badge-warning';
      icon = '⚠';
      break;

    case 'FAILED':
    case 'FAIL':
    case 'REJECTED':
    case 'NON_COMPLIANT':
    case 'HIGH':
      className = 'badge-danger';
      icon = '✕';
      break;

    case 'MISMATCH':
      className = 'badge-mismatch';
      icon = '≠';
      label = 'MISMATCH';
      break;

    case 'EXPIRED':
      className = 'badge-expired';
      icon = '⧗';
      label = 'EXPIRED';
      break;

    case 'MISSING':
      className = 'badge-missing';
      icon = '∅';
      label = 'MISSING';
      break;

    case 'RETRY_REQUIRED':
      className = 'badge-retry';
      icon = '⟳';
      label = 'RETRY REQUIRED';
      break;

    case 'INSUFFICIENT_EVIDENCE':
      className = 'badge-insufficient';
      icon = 'ℹ';
      label = 'INSUFFICIENT DATA';
      break;

    case 'PENDING':
    case 'MANUAL_REVIEW_REQUESTED':
    default:
      className = 'badge-neutral';
      icon = '⏳';
      break;
  }

  return (
    <span className={`status-badge ${className} size-${size}`}>
      <span className="badge-icon" aria-hidden="true">{icon}</span>
      <span className="badge-label">{label}</span>
    </span>
  );
}
