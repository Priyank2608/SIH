'use client';
import React, { useState } from 'react';
import { api } from '../lib/api';

interface DecisionModalProps {
  tenderId: number;
  bidderId: number;
  bidderName: string;
  currentDecision?: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function DecisionModal({
  tenderId,
  bidderId,
  bidderName,
  currentDecision,
  onClose,
  onSuccess
}: DecisionModalProps) {
  const [decision, setDecision] = useState<'ACCEPTED' | 'REJECTED' | 'MANUAL_REVIEW_REQUESTED'>('ACCEPTED');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) {
      setError('Please provide officer justification notes for this official procurement record.');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      await api(`/tenders/${tenderId}/bidders/${bidderId}/decision`, {
        method: 'POST',
        body: JSON.stringify({
          decision,
          decision_notes: notes.trim()
        })
      });
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to record decision');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container modal-md" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="modal-pretitle">Human-in-the-Loop Authority Action</div>
            <h2 className="modal-title">Record Official Procurement Decision</h2>
            <div className="modal-meta">
              <span>Bidder: <b>{bidderName}</b></span>
            </div>
          </div>
          <button className="btn-close" onClick={onClose}>✕</button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="officer-mandate-notice">
              <span className="mandate-icon">⚖️</span>
              <p>
                <b>Statutory Procurement Governance:</b> BidShield AI verification is an assistive intelligence tool.
                The official determination of eligibility, qualification, or disqualification remains solely with the authorized Procurement Officer.
              </p>
            </div>

            {error && <div className="alert alert-danger mb-4">{error}</div>}

            <div className="form-group mb-4">
              <label className="form-label">Official Decision Outcome:</label>
              <div className="decision-radio-group">
                <label className={`radio-card ${decision === 'ACCEPTED' ? 'selected' : ''}`}>
                  <input
                    type="radio"
                    name="decision"
                    value="ACCEPTED"
                    checked={decision === 'ACCEPTED'}
                    onChange={() => setDecision('ACCEPTED')}
                  />
                  <div>
                    <strong className="text-success">Accept / Technically Qualify</strong>
                    <p className="text-xs text-muted">Bidder documents and compliance satisfy tender requirements.</p>
                  </div>
                </label>

                <label className={`radio-card ${decision === 'MANUAL_REVIEW_REQUESTED' ? 'selected' : ''}`}>
                  <input
                    type="radio"
                    name="decision"
                    value="MANUAL_REVIEW_REQUESTED"
                    checked={decision === 'MANUAL_REVIEW_REQUESTED'}
                    onChange={() => setDecision('MANUAL_REVIEW_REQUESTED')}
                  />
                  <div>
                    <strong className="text-warning">Refer for Detailed Scrutiny</strong>
                    <p className="text-xs text-muted">Flag document discrepancies or anomalies for committee evaluation.</p>
                  </div>
                </label>

                <label className={`radio-card ${decision === 'REJECTED' ? 'selected' : ''}`}>
                  <input
                    type="radio"
                    name="decision"
                    value="REJECTED"
                    checked={decision === 'REJECTED'}
                    onChange={() => setDecision('REJECTED')}
                  />
                  <div>
                    <strong className="text-danger">Reject / Technically Disqualify</strong>
                    <p className="text-xs text-muted">Bidder fails mandatory statutory criteria or submitted non-compliant documents.</p>
                  </div>
                </label>
              </div>
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="decision-notes">
                Officer Justification & Evaluation Notes <span className="text-danger">*</span>:
              </label>
              <textarea
                id="decision-notes"
                className="form-textarea"
                rows={4}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Enter justification citing verified certificates, compliance results, or discrepancy grounds..."
                required
              />
              <span className="form-hint">This decision and rationale will be permanently recorded in the immutable audit log.</span>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="btn btn-outline" onClick={onClose} disabled={submitting}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Recording Decision...' : 'Commit Official Decision'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
