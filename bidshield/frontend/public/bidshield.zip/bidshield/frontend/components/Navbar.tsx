'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { getCurrentUser, clearToken } from '../lib/api';

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, [pathname]);

  const handleLogout = () => {
    clearToken();
    router.push('/login');
  };

  const navLinks = [
    { label: 'Executive Dashboard', href: '/' },
    { label: 'Tenders Workspace', href: '/tenders' },
    { label: 'Bidders 360', href: '/bidders' },
    { label: 'Verification Control Center', href: '/verification' },
    { label: 'Reports Archive', href: '/reports' },
    { label: 'Audit Trail', href: '/audit' },
  ];

  if (pathname === '/login') return null;

  return (
    <header className="navbar-container">
      <div className="gov-topbar">
        <div className="gov-inner">
          <div className="gov-identity">
            <span className="gov-flag">🇮🇳</span>
            <span>Government of India • Ministry of Commerce & Industry • GeM Procurement Authority</span>
          </div>
          <div className="gov-support">
            <span>SIH26100 AI Compliance Verification Platform</span>
            <span className="badge-demo">PROTOTYPE DEMO MODE</span>
          </div>
        </div>
      </div>

      <div className="main-navbar">
        <div className="nav-brand">
          <Link href="/" className="brand-link">
            <div className="brand-logo-shield">🛡️</div>
            <div className="brand-text">
              <span className="brand-title">BIDSHIELD</span>
              <span className="brand-sub">AI GeM Compliance Verification</span>
            </div>
          </Link>
        </div>

        <nav className="nav-links">
          {navLinks.map((link) => {
            const isActive = link.href === '/' ? pathname === '/' : pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`nav-item ${isActive ? 'active' : ''}`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="nav-user-actions">
          {user ? (
            <div className="user-profile">
              <div className="user-avatar">{user.full_name?.[0] || 'O'}</div>
              <div className="user-meta">
                <span className="user-name">{user.full_name || user.username}</span>
                <span className="user-role">{user.role?.replace('_', ' ')}</span>
              </div>
              <button onClick={handleLogout} className="btn-logout" title="Sign Out">
                Logout
              </button>
            </div>
          ) : (
            <Link href="/login" className="btn-login-nav">Officer Login</Link>
          )}
        </div>
      </div>
    </header>
  );
}
