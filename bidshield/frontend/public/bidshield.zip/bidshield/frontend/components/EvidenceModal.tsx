'use client';
import React, { useState, useEffect } from 'react';
import { api } from '../lib/api';

interface EvidenceModalProps {
  bidderId: number;
  bidderName: string;
  onClose: () => void;
}

export default function EvidenceModal({ bidderId, bidderName, onClose }: EvidenceModalProps) {
  const [evidenceList, setEvidenceList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const res = await api(`/bidders/${bidderId}/evidence`);
        setEvidenceList(res);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [bidderId]);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container modal-lg" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <div className="modal-pretitle">Cryptographic & Traceable Audit Lineage</div>
            <h2 className="modal-title">Evidence Graph & Traceability Chain</h2>
            <div className="modal-meta">
              <span>Bidder: <b>{bidderName}</b></span>
              <span>Total Evidence Nodes: <b>{evidenceList.length}</b></span>
            </div>
          </div>
          <button className="btn-close" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          {loading ? (
            <div className="text-center p-8">
              <div className="spinner"></div>
              <p>Traversing evidence graph...</p>
            </div>
          ) : evidenceList.length === 0 ? (
            <div className="empty-state p-6 text-center">
              <p className="text-muted">No evidence records currently linked to this bidder profile.</p>
            </div>
          ) : (
            <div className="evidence-timeline">
              {evidenceList.map((ev, idx) => (
                <div key={ev.id || idx} className="evidence-card">
                  <div className="evidence-header">
                    <span className="evidence-tag">{ev.claim_type}</span>
                    <span className="evidence-conf">Confidence: {(ev.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <p className="evidence-text">{ev.evidence_text}</p>
                  <div className="evidence-footer">
                    <span className="evidence-source">
                      Source Ref: <b>{ev.source_reference}</b>
                    </span>
                    <span className="evidence-date">
                      {ev.created_at ? new Date(ev.created_at).toLocaleString() : ''}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn btn-outline" onClick={onClose}>Close Evidence View</button>
        </div>
      </div>
    </div>
  );
}
