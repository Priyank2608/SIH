# BidShield: AI-Powered GeM Bid Compliance Verification Platform

> **Smart India Hackathon 2026** • Problem Statement ID: **SIH26100**  
> **Theme:** Smart Automation • **Category:** Software  
> **Team:** Ascent-X

---

## 1. Overview & Core Product Objective
**BidShield** is an internal procurement-authority-side intelligence platform designed specifically for evaluating and verifying bids submitted on the **Government e-Marketplace (GeM)**.

BidShield assists authorized procurement officers by executing an evidence-linked, tender-aware verification pipeline while ensuring that:
- **THE FINAL PROCUREMENT DECISION ALWAYS REMAINS WITH THE AUTHORIZED PROCUREMENT OFFICER.**
- **AI assists the officer.** AI **NEVER** independently approves, rejects, qualifies, or disqualifies a bidder.
- **Strict Authority-Side Boundary:** No bidder logins, self-service portals, or bidder marketplaces.
- **Explainable Multi-Dimensional Risk:** Clear distinction between "Low Risk" and "Insufficient Evidence". Anomaly detection never equates anomaly with fraud ("Unusual pattern detected").

```
Tender Document (PDF)
  ↓
Requirement Extraction (AI-assisted)
  ↓
Officer Reviews & Approves Requirements
  ↓
Bidder Submissions & Synthetic Documents (PDFs)
  ↓
Multi-Engine OCR (Tesseract / PyMuPDF Layout Extractor)
  ↓
Structured Field Extraction (GSTIN, PAN, Udyam, OEM ID, Turnover, Experience)
  ↓
Registry Verification (Demo GSTN, NSDL, Udyam, OEM Portals)
  ↓
Deterministic Compliance Rule Engine (GST-001, PAN-001, UDYAM-001, OEM-001, etc.)
  ↓
Historical Performance & Documented Delay Cause Tracking
  ↓
8-Dimensional Explainable Risk Engine
  ↓
Cryptographic Evidence Lineage Graph
  ↓
Procurement Officer Review & Formal Determination
  ↓
Immutable Audit Trail & Dual ReportLab PDF Generation
```

---

## 2. Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 19, Next.js 15 (App Router), TypeScript, Native Responsive UI |
| **Backend** | Python 3.11+, FastAPI, Pydantic v2, SQLAlchemy 2.0, ReportLab PDF Engine |
| **Database** | PostgreSQL 16 (Docker) / SQLite (Standalone Demo Mode) |
| **OCR & Document AI** | Tesseract OCR (`pytesseract`), PyMuPDF (`fitz`), PIL Layout Analyzer |
| **Security & Auth** | OAuth2 Bearer JWT, Role-Based Access Control (RBAC), PBKDF2 Password Hashing |
| **Containerization** | Docker, Docker Compose |

---

## 3. Demo Credentials
| Role | Username | Password |
|---|---|---|
| **Procurement Officer** | `officer` | `BidShield@123` |
| **Vigilance Auditor** | `auditor` | `BidShield@123` |
| **System Administrator** | `admin` | `BidShield@123` |

---

## 4. Synthetic Demo Dataset
The platform comes pre-seeded with realistic, interconnected procurement data:
- **5 GeM Tenders:**
  1. `GEM/2026/B/0012345`: Supply of Enterprise Desktop Computers (₹4.5 Cr)
  2. `GEM/2026/B/0023456`: Cloud Infrastructure & Cybersecurity SOC Auditing (₹12.0 Cr)
  3. `GEM/2026/B/0034567`: Specialized ICU Ventilators & Medical Equipment (₹8.0 Cr)
  4. `GEM/2026/B/0045678`: 33/11kV Electrical Transformers & Switchgear (₹18.5 Cr)
  5. `GEM/2026/B/0056789`: 2MW Rooftop Solar PV Installation & AMC (₹6.2 Cr)
- **10 Synthetic Bidders:**
  - *Alpha Technologies Pvt Ltd* (Scenario 1: Fully verified prime contractor)
  - *Bharat Systems Pvt Ltd* (Scenario 2: GSTIN mismatch between profile and certificate)
  - *Gamma Infotech Pvt Ltd* (Scenario 5 & 7: Expired Udyam v1, Corrected v2; v1 preserved)
  - *Delta Digital Solutions* (Scenario 4: Degraded scan triggering `MANUAL_REVIEW`)
  - *Epsilon Engineering Pvt Ltd* (Scenario 6: Simulated provider timeout triggering `RETRY_REQUIRED`)
  - *Zeta Innovations Corp* (Scenario 3: Missing mandatory OEM Authorization letter)
  - *Hindustan Cloud & Networks* (100% on-time delivery across high-value contracts)
  - *Apex Medical Systems Ltd* (Documented Force Majeure supply chain delay)
  - *Dynamic Heavy Electricals* (Startup with 0 past contracts: `INSUFFICIENT_EVIDENCE != LOW_RISK`)
  - *Surya Urja Green Technologies* (Make-in-India 58% local content verified)
- **66 Real Synthetic PDF Documents:**
  - Every document is generated via ReportLab with visible banner: `BIDSHIELD • SYNTHETIC DEMO DOCUMENT`.
  - Cryptographically hashed with SHA-256 and stored with full version lineage.

---

## 5. Quick Start (Local Run)

### Prerequisites
- Python 3.11+
- Node.js 18+ and npm

### 1. Backend Setup
```bash
cd backend
python -m venv .venv

# On Windows:
.venv\Scripts\activate
# On Linux/macOS:
# source .venv/bin/activate

pip install -r requirements.txt
python scripts/seed.py
uvicorn app.main:app --reload --port 8000
```
Backend API Docs will be available at: `http://localhost:8000/api/v1/docs`

### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Open `http://localhost:3000` and sign in using `officer / BidShield@123`.

---

## 6. Docker Deployment

To launch the complete containerized stack (PostgreSQL + FastAPI Backend + Next.js Frontend):
```bash
docker compose up --build
```
- Web Application: `http://localhost:3000`
- REST API Documentation: `http://localhost:8000/api/v1/docs`

---

## 7. Running Tests

Run the full automated test suite (Unit, API, 19-Step End-to-End Workflow, and Demonstration Scenarios):
```bash
cd backend
.venv\Scripts\python.exe -m pytest ../tests -v
```
All 10 test suites pass with 100% test assertion coverage.

---

## 8. Dual ReportLab PDF Reports
BidShield generates two primary official reports:
1. **REPORT 1: Executive Bidder Summary (Quick List)**
   - Matrix of all bidders for a tender showing compliance percentage, verification statuses, overall risk rating, and human review flags.
2. **REPORT 2: Detailed Bidder Assessment Dossier**
   - Multi-page comprehensive dossier with submitted document hashes, OCR extraction data, verification provider notes, deterministic rule checklists, historical delivery causes, 8-dimensional risk breakdown, and SHA-256 integrity seal.

---

## 9. Security & Production Hardening
- **Authentication:** Short-lived JWTs (120 mins) with secure payload encryption.
- **RBAC:** Strict roles (`SUPER_ADMIN`, `PROCUREMENT_OFFICER`, `VERIFICATION_OFFICER`, `AUDITOR`, `REVIEWER`).
- **File Validation:** MIME type checks, SHA-256 hash checks, and private byte storage.
- **Audit Ledger:** Append-only database logs tracking every authentication event, OCR execution, verification job, requirement approval, and officer decision.
- **Error Hygiene:** Sanitized exceptions that never leak stack traces, internal paths, or credentials.
